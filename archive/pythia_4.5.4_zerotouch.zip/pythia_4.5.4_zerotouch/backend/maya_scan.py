# -*- coding: utf-8 -*-
"""ОРАКУЛ // ПИФИЯ — МАЙЯ-СКАНЕР: длительное ОНЛАЙН-наблюдение за стаканом.

Зачем. Один снимок стакана — это фотография; маркетмейкер работает ВО ВРЕМЕНИ:
он держит вакуум, двигает стены, копит натяжение. Сканер тикает по Tinkoff
(стакан 50 уровней + лента) каждые SCAN_INTERVAL_S секунд, часами, копит
снимки и выводит из НАКОПЛЕННОГО:

  · ПРОКОЛЫ (будущие быстрые проходы цены): ценовые полосы, где вакуум
    ДЕРЖИТСЯ во времени (persistence = доля тиков, где полоса была
    разрежена). Пустота, которую держат подолгу, — это подготовленный
    коридор имплозии: попав туда, цена летит без сопротивления. 🔵 доля
    тиков — арифметика; 🟡 слово «прокол» — словарь Майи.
  · КУДА ТЯНУТ СЕЙЧАС: консенсус тяги по тикам (доля «вверх»/«вниз»)
    + серия последних тиков + согласие агрессора ленты.
  · СТЕНЫ И СТЕНЫ-ПРИЗРАКИ: устойчивость цены стены по тикам; крупная,
    но мигрирующая стена — ложный упор (призрак): её отодвигают.
  · НАТЯЖЕНИЕ: тренд глубины лучшего вакуума (последняя треть против
    первой) — растёт → взрыв зреет.
  · ЭФИРНАЯ ПРИВЯЗКА: окно бифуркации Пригожина по наталу тикера
    (reactor_sky) — «когда среда готова порваться» рядом с «куда тянут».

Рамка: 🔵 арифметика снимков · 🟡 словарь Майи · ⚫ НЕ торговый сигнал,
рынок не предсказывается, решение за человеком · 18+.
NO DUMMIES: нет токена/стакана → честный отказ; сканер не выдумывает тики.
Никакого random. Сеть здесь ЗАКОННА: это онлайн-слой поверх Tinkoff API
(ABSOLUTE OFFLINE относится к расчёту неба, не к бирже).
"""
from __future__ import annotations

import asyncio
import time
from collections import deque

try:
    from . import maya                    # обычный импорт пакетом
except ImportError:                       # запуск файла напрямую (self-тест)
    import maya                           # noqa: F401

# tinkoff и reactor_sky нужны только живому скану (start/_scan_loop);
# self-тест агрегатов работает без них — импорт в защите, NO DUMMIES
try:
    from . import tinkoff
except Exception:                         # noqa: BLE001 — прямой запуск файла
    tinkoff = None

try:
    from . import reactor_sky
except Exception:                         # реактор недоступен / прямой запуск
    reactor_sky = None

SCAN_INTERVAL_S = 3.0        # тик сканера: стакан+лента (≈20 пар запросов/мин)
MAX_MINUTES = 480            # верхний предел одного скана (8 часов)
MAX_SNAPSHOTS = 9600         # кольцо снимков (8 ч × 20/мин)
TAPE_MINUTES = 5             # окно ленты (диета: на SBER 15 мин = десятки
                             # тысяч сделок КАЖДЫЙ тик — душило CPU)
TAPE_EVERY = 5               # ленту тянем каждый 5-й тик (стакан — каждый)
ERR_STOP = 40                # подряд ошибок → скан честно останавливается
BACKOFF_MAX_S = 30.0         # при ошибках интервал растёт до этого предела
PUNCTURE_MIN_SHARE = 0.35    # полоса-прокол: вакуум держится ≥35% тиков
PUNCTURE_TOP = 3             # полос на сторону
GHOST_STABILITY = 0.40       # стена стоит на одной цене реже 40% тиков → призрак
STREAK_WIN = 20              # серия «сейчас»: последние N тиков
MIN_TICKS_AGG = 10           # меньше тиков — агрегаты честно не считаются

VERDICT_FRAME = ("⚫ сканер сингулярностей: доли тиков и суммы уровней — "
                 "арифметика 🔵, «прокол/тяга/призрак/ударная волна» — словарь "
                 "первоисточника 🟡 · НЕ торговый сигнал · 18+")

_SCANS: dict[str, dict] = {}          # code → состояние скана
_LOCK = asyncio.Lock()


# ── снимок одного тика ────────────────────────────────────────────────────────
def _snapshot(m: dict, ob: dict) -> dict | None:
    if not (isinstance(m, dict) and m.get("available")):
        return None
    pull = m.get("pull") or {}
    ag = m.get("aggressor") or {}
    return {"ts": time.time(),
            "bid": ob.get("best_bid"), "ask": ob.get("best_ask"),
            "spread_bps": ob.get("spread_bps"),
            "pull": pull.get("side"),
            "s_up": pull.get("score_up"), "s_dn": pull.get("score_dn"),
            "vu": m.get("vacuum_up"), "vd": m.get("vacuum_down"),
            "wa": m.get("wall_ask"), "wb": m.get("wall_bid"),
            "ar": ag.get("ratio") if isinstance(ag, dict) else None,
            "imb": ob.get("imbalance")}


# ── агрегаты по накопленному ─────────────────────────────────────────────────
def _price_step(snaps: list) -> float | None:
    """Шаг полосы — из ширины типичной вакуум-зоны (VAC_WIN уровней)."""
    widths = [abs(v["p_to"] - v["p_from"])
              for s in snaps for v in (s.get("vu"), s.get("vd"))
              if isinstance(v, dict) and v.get("p_from") and v.get("p_to")]
    if not widths:
        return None
    w = sorted(widths)[len(widths) // 2]
    return (w / maya.VAC_WIN) or None


def _punctures(snaps: list, key: str, step: float) -> list:
    """Полосы устойчивого вакуума стороны: bin по центру зоны, persistence."""
    bins: dict[int, dict] = {}
    n = 0
    for s in snaps:
        v = s.get(key)
        if not (isinstance(v, dict) and v.get("p_from") is not None):
            continue
        n += 1
        c = (float(v["p_from"]) + float(v["p_to"])) / 2.0
        b = int(round(c / step))
        r = bins.setdefault(b, {"hits": 0, "depth_sum": 0.0,
                                "p_lo": c, "p_hi": c})
        r["hits"] += 1
        r["depth_sum"] += float(v.get("depth") or 0.0)
        r["p_lo"] = min(r["p_lo"], float(v["p_from"]))
        r["p_hi"] = max(r["p_hi"], float(v["p_to"]))
    if n < MIN_TICKS_AGG:
        return []
    out = []
    for b, r in bins.items():
        share = r["hits"] / n
        if share >= PUNCTURE_MIN_SHARE:
            out.append({"p_lo": round(r["p_lo"], 6), "p_hi": round(r["p_hi"], 6),
                        "persistence": round(share, 3),
                        "depth_mean": round(r["depth_sum"] / r["hits"], 3),
                        "ticks": r["hits"]})
    out.sort(key=lambda x: (-x["persistence"], -x["depth_mean"]))
    return out[:PUNCTURE_TOP]


def _wall_report(snaps: list, key: str) -> dict | None:
    """Устойчивость стены: мода цены; редкая мода = стена-призрак."""
    prices = [round(float(s[key]["p"]), 6) for s in snaps
              if isinstance(s.get(key), dict) and s[key].get("p") is not None]
    total = len(snaps)
    if total < MIN_TICKS_AGG or not prices:
        return None
    freq: dict[float, int] = {}
    for p in prices:
        freq[p] = freq.get(p, 0) + 1
    mode_p = max(freq, key=lambda p: freq[p])
    stability = freq[mode_p] / total          # доля ВСЕХ тиков на модной цене
    present = len(prices) / total
    last = next((s[key] for s in reversed(snaps)
                 if isinstance(s.get(key), dict)), None)
    ghost = bool(present >= 0.5 and stability < GHOST_STABILITY)
    return {"p_mode": mode_p, "stability": round(stability, 3),
            "present": round(present, 3), "now": last, "ghost": ghost,
            "word": ("стена-призрак: крупная, но мигрирует — упор ложный, её "
                     "отодвигают" if ghost else
                     "стена стоит — упор пока настоящий" if present >= 0.5 else
                     "стена появляется эпизодами")}


def _tension(snaps: list) -> dict | None:
    """Тренд глубины лучшего вакуума: последняя треть против первой."""
    depths = []
    for s in snaps:
        best = max((float(v.get("depth") or 0.0)
                    for v in (s.get("vu"), s.get("vd")) if isinstance(v, dict)),
                   default=None)
        if best is not None:
            depths.append(best)
    if len(depths) < MIN_TICKS_AGG:
        return None
    k = max(1, len(depths) // 3)
    a = sum(depths[:k]) / k
    b = sum(depths[-k:]) / k
    d = b - a
    word = ("натяжение РАСТЁТ — вакуум углубляется, взрыв зреет" if d > 0.05
            else "натяжение спадает — вакуум заполняют" if d < -0.05
            else "натяжение ровное")
    return {"first": round(a, 3), "last": round(b, 3),
            "delta": round(d, 3), "word": word}


def _synth_dpdt(snaps: list) -> dict | None:
    """∂P_synth/∂t из первоисточника: скорость СОЗДАНИЯ вакуума и ударная
    волна. «Если скачок производной — фиксируем Ударную Волну»: резкое
    углубление/заливка вакуума между соседними тиками = синтетическую
    сингулярность строят (или сносят) ПРЯМО СЕЙЧАС. 🔵 разности глубин —
    арифметика; 🟡 слова — словарь первоисточника."""
    if len(snaps) < MIN_TICKS_AGG:
        return None
    def _depth(s, key):
        v = s.get(key)
        return float(v.get("depth") or 0.0) if isinstance(v, dict) else 0.0
    out = {}
    for key, side in (("vu", "вверх"), ("vd", "вниз")):
        d = [_depth(s, key) for s in snaps]
        k = min(5, len(d) - 1)
        speed = (sum(d[-k:]) / k - sum(d[-2 * k:-k]) / k) if len(d) >= 2 * k else 0.0
        jump = max((abs(d[i] - d[i - 1]) for i in range(len(d) - k, len(d))
                    if i >= 1), default=0.0)
        out[key] = {"speed": round(speed, 3), "jump": round(jump, 3)}
    su, sd = out["vu"]["speed"], out["vd"]["speed"]
    jmax = max(out["vu"]["jump"], out["vd"]["jump"])
    if jmax >= 0.25:
        word = "УДАРНАЯ ВОЛНА: глубина вакуума скакнула — сингулярность строят/сносят прямо сейчас"
    elif max(su, sd) >= 0.03:
        side = "над ценой" if su >= sd else "под ценой"
        word = f"∂P/∂t > 0: вакуум {side} углубляют — синтетическую сингулярность готовят"
    elif min(su, sd) <= -0.03:
        word = "вакуум заливают — сингулярность разбирают"
    else:
        word = "производная спокойна — вакуум держат без рывков"
    return {"up": out["vu"], "down": out["vd"], "jump_max": round(jmax, 3),
            "word": word}


def _consensus(snaps: list) -> dict | None:
    n = len(snaps)
    if n < MIN_TICKS_AGG:
        return None
    up = sum(1 for s in snaps if s.get("pull") == "вверх")
    dn = sum(1 for s in snaps if s.get("pull") == "вниз")
    tail = snaps[-STREAK_WIN:]
    t_up = sum(1 for s in tail if s.get("pull") == "вверх")
    t_dn = sum(1 for s in tail if s.get("pull") == "вниз")
    # консенсус: сторона держит ≥55% тиков и превосходит другую — 🟡 порог школы
    side = ("вверх" if up / n >= 0.55 and up > dn else
            "вниз" if dn / n >= 0.55 and dn > up else None)
    tn = len(tail) or 1
    now_side = ("вверх" if t_up / tn >= 0.55 and t_up > t_dn else
                "вниз" if t_dn / tn >= 0.55 and t_dn > t_up else None)
    ars = [s["ar"] for s in tail if s.get("ar") is not None]
    ar = (sum(ars) / len(ars)) if ars else None
    agree = None
    if ar is not None and now_side:
        agree = bool(ar > 0.55) if now_side == "вверх" else bool(ar < 0.45)
    word = (f"тянут {side or now_side}" if (side or now_side)
            else "выраженной тяги за окно нет")
    if side and now_side and side != now_side:
        word = f"за всё окно тянули {side}, последние тики — {now_side} (перекладка?)"
    return {"up_share": round(up / n, 3), "dn_share": round(dn / n, 3),
            "side": side, "now_side": now_side,
            "streak": {"win": len(tail), "up": t_up, "dn": t_dn},
            "aggressor_mean": (round(ar, 3) if ar is not None else None),
            "agree": agree, "word": word}


def aggregate(state: dict) -> dict:
    """Живой отчёт скана: тяга-консенсус, проколы, стены, натяжение, эфир."""
    snaps = list(state["snaps"])
    n = len(snaps)
    out = {"running": bool(state.get("task") and not state["task"].done()),
           "ticks": n, "errors": state.get("errors", 0),
           "started": state.get("started"), "until": state.get("until"),
           "elapsed_min": round((time.time() - state["started"]) / 60.0, 1)
           if state.get("started") else None,
           "interval_s": SCAN_INTERVAL_S,
           "last": snaps[-1] if snaps else None,
           "note": state.get("note"), "verdict": VERDICT_FRAME}
    if n < MIN_TICKS_AGG:
        out["agg_note"] = (f"накоплено {n} тиков — агрегаты честно молчат "
                           f"до {MIN_TICKS_AGG} (NO DUMMIES)")
        return out
    step = _price_step(snaps)
    out["consensus"] = _consensus(snaps)
    if step:
        pu = _punctures(snaps, "vu", step)
        pd = _punctures(snaps, "vd", step)
        out["punctures"] = {"up": pu, "down": pd, "bin_step": round(step, 6)}
        first = None
        cons = out["consensus"] or {}
        lead = cons.get("now_side") or cons.get("side")
        cand = pu if lead == "вверх" else pd if lead == "вниз" else []
        if cand:
            first = dict(cand[0], side=lead,
                         word=f"прокол вероятен первым {lead}: вакуум держат "
                              f"{int(cand[0]['persistence']*100)}% времени")
        out["puncture_first"] = first
    out["wall_ask"] = _wall_report(snaps, "wa")
    out["wall_bid"] = _wall_report(snaps, "wb")
    out["tension"] = _tension(snaps)
    out["synth"] = _synth_dpdt(snaps)
    out["ether"] = state.get("ether")
    return out


# ── жизненный цикл скана ─────────────────────────────────────────────────────
async def _scan_loop(code: str, figi: str, ticker: str) -> None:
    st = _SCANS[code]
    tick = 0
    err_streak = 0                       # подряд неудачных тиков
    last_tape = None                     # лента живёт TAPE_EVERY тиков
    while time.time() < st["until"]:
        tick += 1
        ok_tick = False
        try:
            ob = await tinkoff.orderbook(figi, depth=50)
            if tick % TAPE_EVERY == 1:   # диета: лента каждый 5-й тик
                last_tape = await tinkoff.last_trades(figi, minutes=TAPE_MINUTES)
            if ob:
                m = maya.analyze(ob, last_tape)
                snap = _snapshot(m, ob)
                if snap:
                    st["snaps"].append(snap)
                    ok_tick = True
                else:
                    st["errors"] += 1
            else:
                st["errors"] += 1
        except asyncio.CancelledError:
            raise
        except Exception as e:                          # тик упал — скан живёт
            st["errors"] += 1
            st["note"] = f"последняя ошибка тика: {str(e)[:100]}"
        # стойкость: серия ошибок → бэкофф; длинная серия → честный стоп
        if ok_tick:
            err_streak = 0
        else:
            err_streak += 1
            if err_streak >= ERR_STOP:
                st["note"] = (f"скан остановлен: {err_streak} тиков подряд без "
                              "данных (биржа закрыта / сеть / токен) — жми СКАН "
                              "заново, когда стакан оживёт")
                return
        delay = min(BACKOFF_MAX_S, SCAN_INTERVAL_S * (2 ** min(err_streak, 4)))             if err_streak else SCAN_INTERVAL_S
        await asyncio.sleep(delay)
    st["note"] = st.get("note") or "скан завершён по таймеру"


async def start(code: str, ticker: str, asset_class: str,
                minutes: int) -> dict:
    """Запуск (перезапуск) скана инструмента. Возвращает статус."""
    if tinkoff is None or not tinkoff.enabled():
        return {"ok": False, "note": "нет TINKOFF_TOKEN — онлайн-сканер "
                                     "честно недоступен (NO DUMMIES)"}
    minutes = max(1, min(int(minutes or 15), MAX_MINUTES))
    inst = await tinkoff.resolve(ticker, asset_class)
    if not inst:
        return {"ok": False, "note": f"инструмент {ticker} не разрешился"}
    figi = inst.get("figi") or inst.get("uid")
    async with _LOCK:
        old = _SCANS.get(code)
        if old and old.get("task") and not old["task"].done():
            # скан УЖЕ идёт → ПРОДЛЕВАЕМ дедлайн, накопленное НЕ сбрасываем
            # (раньше повторное нажатие «8Ч» стирало все тики — цифры плясали)
            old["until"] = max(old["until"], time.time() + minutes * 60.0)
            old["note"] = (f"скан продлён (+{minutes} мин) — накопленные "
                           f"{len(old['snaps'])} тиков сохранены")
            return {"ok": True, "minutes": minutes, "code": code,
                    "extended": True}
        st = {"snaps": deque(maxlen=MAX_SNAPSHOTS), "errors": 0,
              "started": time.time(),
              "until": time.time() + minutes * 60.0,
              "note": None, "ether": None, "task": None}
        _SCANS[code] = st
        st["task"] = asyncio.create_task(_scan_loop(code, figi, ticker))
    # эфирная привязка — один раз на старт, в потоке (не держит event loop)
    if reactor_sky is not None:
        try:
            ctx = await asyncio.to_thread(reactor_sky.reactor_context, ticker)
            pr = (ctx or {}).get("prigogine")
            st["ether"] = {"prigogine": pr,
                           "note": "окно Пригожина по наталу тикера: КОГДА "
                                   "среда готова порваться (🟡 прокси школы)"}
        except Exception as e:
            st["ether"] = {"prigogine": None, "note": f"эфир молчит: {str(e)[:80]}"}
    return {"ok": True, "minutes": minutes, "code": code}


_AGG_TTL = 2.5               # сек: чаще агрегаты не пересчитываем (кэш)


def status(code: str) -> dict:
    st = _SCANS.get(code)
    if not st:
        return {"running": False, "ticks": 0,
                "note": "скан не запускался", "verdict": VERDICT_FRAME}
    cached = st.get("_agg_cache")
    now = time.time()
    if cached and now - cached[0] < _AGG_TTL and cached[1].get("ticks") == len(st["snaps"]):
        return cached[1]
    agg = aggregate(st)
    st["_agg_cache"] = (now, agg)
    return agg


def stop(code: str) -> dict:
    st = _SCANS.get(code)
    if st and st.get("task") and not st["task"].done():
        st["task"].cancel()
        st["note"] = "остановлен вручную"
        return {"ok": True, "note": "скан остановлен"}
    return {"ok": False, "note": "активного скана нет"}


# ── self-test: агрегаты на синтетических снимках (сеть не нужна) ─────────────
if __name__ == "__main__":
    # 40 тиков: вакуум над ценой держится в одной полосе 70% времени,
    # тяга вверх 60% тиков, стена bid мигрирует (призрак)
    snaps = []
    for i in range(40):
        vu = ({"p_from": 101.1, "p_to": 101.5, "depth": 0.9}
              if i % 10 < 7 else {"p_from": 103.0, "p_to": 103.4, "depth": 0.4})
        snaps.append({
            "ts": 1000.0 + i * 3, "bid": 100.0, "ask": 100.1,
            "pull": ("вверх" if i % 5 < 3 else "вниз"),
            "s_up": 0.6, "s_dn": 0.2, "vu": vu,
            "vd": {"p_from": 98.0, "p_to": 98.4, "depth": 0.2 + 0.01 * i},
            "wa": {"p": 102.0, "q": 500, "mult": 5.0},
            "wb": {"p": round(99.5 - 0.01 * i, 2), "q": 900, "mult": 6.0},
            "ar": 0.62, "imb": 0.1})
    st = {"snaps": deque(snaps), "errors": 0, "started": 1000.0,
          "until": 1000.0 + 3600, "task": None, "ether": None}
    agg = aggregate(st)
    assert agg["ticks"] == 40
    c = agg["consensus"]
    assert c["side"] == "вверх" or c["now_side"] == "вверх", c
    assert c["agree"] is True                      # агрессор 0.62 согласен
    pu = agg["punctures"]["up"]
    assert pu and abs(pu[0]["p_lo"] - 101.1) < 1e-9 and pu[0]["persistence"] >= 0.6
    pf = agg["puncture_first"]
    assert pf and pf["side"] == "вверх" and "прокол" in pf["word"]
    wa = agg["wall_ask"]; wb = agg["wall_bid"]
    assert wa and wa["ghost"] is False and "стоит" in wa["word"]
    assert wb and wb["ghost"] is True and "призрак" in wb["word"]
    tn = agg["tension"]
    # глубина лучшего вакуума стабильно 0.9 (up доминирует) — тренд ровный;
    # проверяем сам расчёт долей
    assert tn and tn["first"] >= 0.0 and tn["last"] >= tn["first"] - 1.0
    # мало тиков → агрегаты молчат
    st2 = {"snaps": deque(snaps[:5]), "errors": 0, "started": 1000.0,
           "until": 4600.0, "task": None, "ether": None}
    a2 = aggregate(st2)
    assert "agg_note" in a2 and "punctures" not in a2
    # детерминизм
    assert repr(aggregate(st)) == repr(agg)
    # ∂P/∂t: базовая синтетика мигает 0.9↔0.4 → скачок ≥0.25 = ударная волна
    assert agg["synth"] and agg["synth"]["jump_max"] >= 0.25
    assert "УДАРНАЯ" in agg["synth"]["word"]
    # ровная серия (глубина константа) → производная спокойна
    snaps_s = [dict(x, vu={"p_from": 101.1, "p_to": 101.5, "depth": 0.9},
                    vd={"p_from": 98.0, "p_to": 98.4, "depth": 0.2})
               for x in snaps]
    sts = {"snaps": deque(snaps_s), "errors": 0, "started": 1000.0,
           "until": 4600.0, "task": None, "ether": None}
    aggs = aggregate(sts)
    assert aggs["synth"]["jump_max"] < 0.25 and (
        "спокойна" in aggs["synth"]["word"] or "держат" in aggs["synth"]["word"])
    # рамка на месте
    assert "18+" in agg["verdict"] and "⚫" in agg["verdict"]
    print("maya_scan self-test OK: проколы/тяга/призрак/натяжение — там, где выложены")
