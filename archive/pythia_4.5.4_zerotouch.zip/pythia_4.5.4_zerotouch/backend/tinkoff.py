"""ОРАКУЛ // ПИФИЯ — глубокий сбор данных из Tinkoff Invest API (REST).

Цель: вытащить МАКСИМУМ по инструменту и упаковать в одно «досье» для ИИ.
Что собираем:
  • метаданные (lot, валюта, сектор, экспирация фьючерса, базовый актив, ГО);
  • реальную цену (GetLastPrices) — без 15-мин лага MOEX;
  • торговый статус;
  • свечи трёх горизонтов (5м/2дня, час/14дней, день/полгода);
  • стакан (GetOrderBook depth=50): стены, дисбаланс, спред, лимиты;
  • ленту сделок (GetLastTrades): агрессор buy/sell, дельта, крупные принты;
  • теханализ Tinkoff (RSI/MACD/EMA/BB);
  • дивиденды (для акций);
  • и десятки производных метрик, посчитанных локально из свечей/стакана/ленты.

Никогда не бросает наружу: при сбое любого блока пишет error и идёт дальше.
"""
from __future__ import annotations

import asyncio
import logging
import math
import time
from datetime import datetime, timedelta, timezone

import httpx

from . import config

logger = logging.getLogger("pythia.tinkoff")

BASE = "https://invest-public-api.tinkoff.ru/rest"
MD = "tinkoff.public.invest.api.contract.v1.MarketDataService"
INS = "tinkoff.public.invest.api.contract.v1.InstrumentsService"

# ── кэши ──────────────────────────────────────────────────────────────
_index_cache: dict[str, tuple[float, dict]] = {}   # kind -> (ts, {ticker:row})
_INDEX_TTL = 3600
_price_cache: dict[str, tuple[float, float]] = {}
_resolve_cache: dict[str, tuple[float, dict]] = {}  # "share:SBER" -> (ts, instrument row)
_RESOLVE_TTL = 6 * 3600.0  # фьючерс экспирирует — без TTL резолвер вечно
                           # держал бы мёртвый контракт до рестарта сервера


def enabled() -> bool:
    return bool(config.TINKOFF_TOKEN)


def _q(q) -> float:
    """Quotation/MoneyValue -> float (units + nano/1e9)."""
    if q is None:
        return 0.0
    if isinstance(q, dict):
        try:
            units = float(q.get("units", 0) or 0)
        except (ValueError, TypeError):
            units = 0.0
        try:
            nano = float(q.get("nano", 0) or 0)
        except (ValueError, TypeError):
            nano = 0.0
        return units + nano / 1e9
    try:
        return float(q)
    except (ValueError, TypeError):
        return 0.0


def _iso(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


# ── ОБЩИЙ HTTP-КЛИЕНТ ─────────────────────────────────────────────────
# Раньше КАЖДЫЙ запрос (цена, свечи, стакан, лента…) открывал НОВЫЙ
# httpx.AsyncClient — то есть новое TCP+TLS-соединение. Живой тикер цены бьёт
# по API каждые 3с несколькими вызовами; за долгую сессию это копило сотни
# TIME_WAIT-сокетов (особенно на Windows с узким диапазоном портов) и добавляло
# ~200-300мс TLS-хендшейка на КАЖДЫЙ вызов. Итог — «чем дальше, тем медленнее».
# Теперь один пул соединений с keep-alive живёт весь процесс и переиспользуется.
_http: httpx.AsyncClient | None = None
_http_lock = asyncio.Lock()


_ca_checked = False

# Публичные CA Минцифры РФ с официального CDN Госуслуг (gosuslugi.ru/crt).
# Сам CDN отдаётся по ОБЫЧНОМУ глобально доверенному TLS — качаем безопасно.
RUS_CA_URLS = (
    "https://gu-st.ru/content/lending/russian_trusted_root_ca_pem.crt",
    "https://gu-st.ru/content/lending/russian_trusted_sub_ca_pem.crt",
)


async def _ensure_russian_ca() -> None:
    """Автолечение CERTIFICATE_VERIFY_FAILED: API Тинькофф подписан корнем
    Минцифры, которого нет в certifi. Если data/russian_trusted.pem ещё нет —
    скачиваем оба сертификата с CDN Госуслуг и складываем рядом. Один раз за
    процесс; не вышло → честный WARNING с ручным рецептом (NO DUMMIES,
    verify НЕ отключаем никогда)."""
    global _ca_checked
    if _ca_checked:
        return
    _ca_checked = True
    pem = config.DATA_DIR / "russian_trusted.pem"
    try:
        if pem.exists() and pem.stat().st_size > 1000:
            return
    except OSError:
        pass
    parts = []
    try:
        async with httpx.AsyncClient(timeout=20.0, follow_redirects=True) as c:
            for url in RUS_CA_URLS:
                r = await c.get(url)
                r.raise_for_status()
                t = r.text.strip()
                if "BEGIN CERTIFICATE" not in t:
                    raise ValueError(f"ответ не PEM: {url}")
                parts.append(t)
        pem.parent.mkdir(parents=True, exist_ok=True)
        pem.write_text("\n".join(parts) + "\n", encoding="ascii")
        logger.info("CA Минцифры скачаны → %s (это чинит доверие к API Тинькофф)", pem)
    except Exception as e:                                 # noqa: BLE001
        logger.warning(
            "CA Минцифры скачать не удалось (%s). Запросы к Тинькофф будут "
            "падать CERTIFICATE_VERIFY_FAILED. Ручной способ: на gosuslugi.ru/crt "
            "скачай «Корневой» и «Выпускающий» сертификаты в формате PEM, склей "
            "содержимое обоих в один файл и сохрани как %s, потом перезапусти. "
            "Если и после этого падает — антивирус перехватывает HTTPS "
            "(Касперский/Dr.Web): выключи «проверку защищённых соединений» "
            "для python.exe.", str(e)[:120], pem)


async def _client() -> httpx.AsyncClient:
    global _http
    h = _http
    if h is not None and not h.is_closed:
        return h
    async with _http_lock:
        if _http is None or _http.is_closed:
            await _ensure_russian_ca()          # сначала доверие, потом клиент
            _http = httpx.AsyncClient(
                timeout=httpx.Timeout(15.0),
                limits=httpx.Limits(max_keepalive_connections=20,
                                    max_connections=40,
                                    keepalive_expiry=60.0),
                headers={"Content-Type": "application/json"},
                verify=_ssl_context(),
            )
        return _http


def _ssl_context():
    """TLS-доверие для Тинькофф Инвест API. С 2022 его сертификат подписан
    корнем Минцифры РФ (Russian Trusted Root CA), которого НЕТ в certifi —
    без него httpx падает CERTIFICATE_VERIFY_FAILED, resolve → None, и
    стакан «молча не работает» (симптом: MOEX и эфемериды живут, стакан нет).
    Здесь: стандартное доверие certifi + публичные CA Минцифры из
    data/russian_trusted.pem — ТОЛЬКО для клиента этого модуля.
    Файла нет / сломан → честно остаёмся на certifi (лог скажет причину)."""
    import ssl
    try:
        import certifi
        ctx = ssl.create_default_context(cafile=certifi.where())
    except Exception:                                  # noqa: BLE001
        ctx = ssl.create_default_context()
    try:
        pem = config.DATA_DIR / "russian_trusted.pem"
        if pem.exists():
            ctx.load_verify_locations(cafile=str(pem))
    except Exception as e:                             # noqa: BLE001
        logger.warning("russian_trusted.pem не подгружен: %s", e)
    return ctx


async def aclose() -> None:
    """Аккуратно закрыть пул (вызывается на остановке сервера)."""
    global _http
    h, _http = _http, None
    if h is not None and not h.is_closed:
        try:
            await h.aclose()
        except Exception:
            pass


async def _post(path: str, body: dict, timeout: float = 15.0) -> dict:
    if not config.TINKOFF_TOKEN:
        raise RuntimeError("Tinkoff token не установлен")
    url = f"{BASE}/{path}"
    headers = {"Authorization": f"Bearer {config.TINKOFF_TOKEN}"}
    cl = await _client()
    r = await cl.post(url, headers=headers, json=body, timeout=timeout)
    r.raise_for_status()
    return r.json()


# ──────────────────────────────────────────────────────────────────────
# Резолвер тикер → инструмент (share/future/currency)
# ──────────────────────────────────────────────────────────────────────

async def _load_index(kind: str) -> dict:
    """kind: 'shares' | 'futures' | 'currencies'. {TICKER: row}."""
    now = time.time()
    c = _index_cache.get(kind)
    if c and now - c[0] < _INDEX_TTL:
        return c[1]
    method = {"shares": "Shares", "futures": "Futures",
              "currencies": "Currencies", "etfs": "Etfs"}.get(kind, "Shares")
    try:
        data = await _post(f"{INS}/{method}",
                           {"instrumentStatus": "INSTRUMENT_STATUS_BASE"}, timeout=25.0)
    except Exception as e:
        logger.warning("load_index %s failed: %s", kind, str(e)[:120])
        return c[1] if c else {}
    idx: dict[str, dict] = {}
    for row in data.get("instruments", []):
        t = (row.get("ticker") or "").upper().strip()
        if t:
            idx.setdefault(t, row)
    _index_cache[kind] = (now, idx)
    return idx


async def prewarm() -> None:
    """Прогреть индексы инструментов (акции/фьючерсы/валюты) в фоне при старте.
    Раньше ПЕРВЫЙ разбор акции тянул ~3МБ каталог Shares синхронно (+4-5с к
    самому первому объекту). Теперь это делается заранее, ещё до первого клика.

    Последовательно, а не разом: три больших (~3МБ) запроса одновременно
    Tinkoff иногда отбивает 504 — грузим по одному, это фон, спешить некуда."""
    if not enabled():
        return
    for kind in ("shares", "futures", "currencies"):
        try:
            await _load_index(kind)
        except Exception:
            pass


async def resolve(ticker: str, asset_class: str) -> dict | None:
    """Вернуть полный instrument-row Tinkoff по тикеру.

    Для фьючерсов: если задан базовый код (BR/NG/SI...) — найдём ближайший
    активный контракт по префиксу тикера и сроку экспирации (авто-роллове́р).
    """
    t = (ticker or "").upper().strip()
    if not t:
        return None
    key = f"{asset_class}:{t}"
    hit = _resolve_cache.get(key)
    if hit and time.time() - hit[0] < _RESOLVE_TTL:
        return hit[1]

    if asset_class == "futures":
        idx = await _load_index("futures")
        # точное совпадение
        if t in idx:
            _resolve_cache[key] = (time.time(), idx[t])
            return idx[t]
        # поиск ближайшего активного контракта по префиксу
        cands = []
        for tk, row in idx.items():
            base = (row.get("basicAsset") or "").upper()
            if tk.startswith(t) or base == t or tk.startswith(t[:2]):
                exp = row.get("expirationDate") or ""
                cands.append((exp, tk, row))
        # только будущие экспирации, ближайшая первой
        now_iso = _iso(datetime.now(timezone.utc))
        future = [c for c in cands if c[0] and c[0] > now_iso]
        future.sort(key=lambda x: x[0])
        chosen = future[0][2] if future else (cands[0][2] if cands else None)
        if chosen:
            _resolve_cache[key] = (time.time(), chosen)
        return chosen

    if asset_class == "currency":
        idx = await _load_index("currencies")
        row = idx.get(t)
        if row:
            _resolve_cache[key] = (time.time(), row)
        return row

    # shares (по умолчанию)
    idx = await _load_index("shares")
    row = idx.get(t)
    if row:
        _resolve_cache[key] = (time.time(), row)
    return row


# ──────────────────────────────────────────────────────────────────────
# Точечные запросы рыночных данных
# ──────────────────────────────────────────────────────────────────────

async def last_price(instrument_id: str) -> dict | None:
    now = time.time()
    ttl = config.TINKOFF_PRICE_CACHE_SEC
    c = _price_cache.get(instrument_id)
    if c and now - c[0] < ttl:
        return {"price": c[1], "ts": c[0], "cached": True}
    try:
        d = await _post(f"{MD}/GetLastPrices", {"instrumentId": [instrument_id]})
    except Exception as e:
        logger.warning("GetLastPrices failed: %s", str(e)[:100])
        return None
    rows = d.get("lastPrices") or []
    if not rows:
        return None
    px = _q(rows[0].get("price"))
    if px <= 0:
        return None
    _price_cache[instrument_id] = (now, px)
    return {"price": px, "ts": now, "quote_time": rows[0].get("time")}


_close_cache: dict[str, tuple[float, float]] = {}
_CLOSE_TTL = 60.0   # цена закрытия прошлой сессии статична внутри дня —
                    # живой тикер дёргал её каждые 3с без нужды


async def close_price(instrument_id: str) -> float | None:
    now = time.time()
    c = _close_cache.get(instrument_id)
    if c and now - c[0] < _CLOSE_TTL:
        return c[1]
    try:
        d = await _post(f"{MD}/GetClosePrices",
                        {"instruments": [{"instrumentId": instrument_id}]})
    except Exception:
        return None
    rows = d.get("closePrices") or []
    if not rows:
        return None
    px = _q(rows[0].get("price")) or None
    if px:
        _close_cache[instrument_id] = (now, px)
    return px


_INTERVAL = {
    "1m": "CANDLE_INTERVAL_1_MIN", "5m": "CANDLE_INTERVAL_5_MIN",
    "15m": "CANDLE_INTERVAL_15_MIN", "30m": "CANDLE_INTERVAL_30_MIN",
    "1h": "CANDLE_INTERVAL_HOUR", "4h": "CANDLE_INTERVAL_4_HOUR",
    "1d": "CANDLE_INTERVAL_DAY", "1w": "CANDLE_INTERVAL_WEEK",
}


async def candles(instrument_id: str, interval: str, days_back: int) -> list[dict]:
    """Свечи. Возвращает [{t,o,h,l,c,v}] в хронологическом порядке."""
    iv = _INTERVAL.get(interval, "CANDLE_INTERVAL_DAY")
    to = datetime.now(timezone.utc)
    frm = to - timedelta(days=days_back)
    try:
        d = await _post(f"{MD}/GetCandles", {
            "instrumentId": instrument_id, "from": _iso(frm), "to": _iso(to),
            "interval": iv,
        }, timeout=25.0)
    except Exception as e:
        logger.warning("GetCandles %s %s failed: %s", instrument_id, interval, str(e)[:100])
        return []
    out = []
    for c in d.get("candles", []):
        out.append({
            "t": c.get("time"),
            "o": round(_q(c.get("open")), 6),
            "h": round(_q(c.get("high")), 6),
            "l": round(_q(c.get("low")), 6),
            "c": round(_q(c.get("close")), 6),
            "v": int(c.get("volume", 0) or 0),
            "complete": c.get("isComplete", True),
        })
    return out


async def orderbook(instrument_id: str, depth: int = 50) -> dict | None:
    try:
        d = await _post(f"{MD}/GetOrderBook",
                        {"instrumentId": instrument_id, "depth": depth})
    except Exception as e:
        logger.warning("GetOrderBook failed: %s", str(e)[:100])
        return None
    bids = [(_q(b.get("price")), int(b.get("quantity", 0) or 0))
            for b in d.get("bids", [])]
    asks = [(_q(a.get("price")), int(a.get("quantity", 0) or 0))
            for a in d.get("asks", [])]
    if not bids and not asks:
        return None
    bid_vol = sum(q for _, q in bids)
    ask_vol = sum(q for _, q in asks)
    tot = bid_vol + ask_vol
    imb = round((bid_vol - ask_vol) / tot, 3) if tot else 0.0
    best_bid = bids[0][0] if bids else 0.0
    best_ask = asks[0][0] if asks else 0.0
    spread = round(best_ask - best_bid, 6) if (best_bid and best_ask) else None
    mid = (best_bid + best_ask) / 2 if (best_bid and best_ask) else 0.0
    spread_bps = round(spread / mid * 1e4, 2) if (spread and mid) else None
    big_bid = max(bids, key=lambda x: x[1]) if bids else None
    big_ask = max(asks, key=lambda x: x[1]) if asks else None
    return {
        "best_bid": best_bid, "best_ask": best_ask, "spread": spread,
        "spread_bps": spread_bps, "bid_vol": bid_vol, "ask_vol": ask_vol,
        "imbalance": imb,
        "top_bids": [{"p": p, "q": q} for p, q in bids[:10]],
        "top_asks": [{"p": p, "q": q} for p, q in asks[:10]],
        # v3.7 (канон 05.08, слой Майи): ПОЛНЫЕ уровни стакана — раньше 50
        # запрошенных уровней выбрасывались, вакуум ликвидности было не из
        # чего считать. Аддитивно: старые ключи не тронуты.
        "levels_bid": [{"p": p, "q": q} for p, q in bids],
        "levels_ask": [{"p": p, "q": q} for p, q in asks],
        "wall_bid": {"p": big_bid[0], "q": big_bid[1]} if big_bid else None,
        "wall_ask": {"p": big_ask[0], "q": big_ask[1]} if big_ask else None,
        "limit_up": _q(d.get("limitUp")) or None,
        "limit_down": _q(d.get("limitDown")) or None,
        "last_price": _q(d.get("lastPrice")) or None,
        "close_price": _q(d.get("closePrice")) or None,
    }


async def last_trades(instrument_id: str, minutes: int = 60) -> dict | None:
    to = datetime.now(timezone.utc)
    frm = to - timedelta(minutes=minutes)
    try:
        d = await _post(f"{MD}/GetLastTrades",
                        {"instrumentId": instrument_id, "from": _iso(frm), "to": _iso(to)})
    except Exception as e:
        logger.warning("GetLastTrades failed: %s", str(e)[:100])
        return None
    trades = d.get("trades", [])
    if not trades:
        return {"count": 0}
    buy_v = sell_v = 0
    buy_n = sell_n = 0
    prints = []
    for tr in trades:
        q = int(tr.get("quantity", 0) or 0)
        p = _q(tr.get("price"))
        direction = tr.get("direction", "")
        if direction == "TRADE_DIRECTION_BUY":
            buy_v += q
            buy_n += 1
        elif direction == "TRADE_DIRECTION_SELL":
            sell_v += q
            sell_n += 1
        prints.append((q, p, direction))
    tot = buy_v + sell_v
    delta = buy_v - sell_v
    prints.sort(reverse=True)
    big = [{"q": q, "p": p, "side": "BUY" if "BUY" in d_ else "SELL"}
           for q, p, d_ in prints[:5]]
    return {
        "count": len(trades), "window_min": minutes,
        "buy_vol": buy_v, "sell_vol": sell_v, "delta": delta,
        "aggressor_ratio": round(buy_v / tot, 3) if tot else None,
        "buy_trades": buy_n, "sell_trades": sell_n,
        "avg_trade_size": round(sum(q for q, _, _ in prints) / len(prints), 1),
        "largest_prints": big,
    }


async def trading_status(instrument_id: str) -> dict | None:
    try:
        d = await _post(f"{MD}/GetTradingStatus", {"instrumentId": instrument_id})
    except Exception:
        return None
    return {
        "status": d.get("tradingStatus"),
        "limit_order": d.get("limitOrderAvailableFlag"),
        "market_order": d.get("marketOrderAvailableFlag"),
        "api_available": d.get("apiTradeAvailableFlag"),
    }


_TECH = {
    "RSI": "INDICATOR_TYPE_RSI", "MACD": "INDICATOR_TYPE_MACD",
    "EMA": "INDICATOR_TYPE_EMA", "SMA": "INDICATOR_TYPE_SMA",
    "BB": "INDICATOR_TYPE_BB",
}


_IND_INTERVAL = {  # у GetTechAnalysis СВОЙ enum интервалов (не CANDLE_INTERVAL_*)
    "1m": "INDICATOR_INTERVAL_ONE_MINUTE", "5m": "INDICATOR_INTERVAL_FIVE_MINUTES",
    "15m": "INDICATOR_INTERVAL_FIFTEEN_MINUTES", "1h": "INDICATOR_INTERVAL_ONE_HOUR",
    "1d": "INDICATOR_INTERVAL_ONE_DAY",
}


async def consensus(instrument_uid: str) -> dict | None:
    """Консенсус аналитиков Tinkoff: рекомендация, целевая цена, апсайд,
    таргеты инвестдомов. То самое «ключевое, что пишут» — в цифрах."""
    try:
        r = await _post("tinkoff.public.invest.api.contract.v1."
                        "InstrumentsService/GetForecastBy",
                        {"instrumentId": instrument_uid})
    except Exception as e:
        logger.warning("consensus: %s", str(e)[:90])
        return None
    cons = r.get("consensus") or {}
    if not cons:
        return None
    reco_map = {"RECOMMENDATION_BUY": "ПОКУПАТЬ", "RECOMMENDATION_HOLD": "ДЕРЖАТЬ",
                "RECOMMENDATION_SELL": "ПРОДАВАТЬ"}
    houses = []
    for t in (r.get("targets") or []):
        tp = _q(t.get("targetPrice"))
        if tp:
            houses.append({"company": t.get("company"),
                           "reco": reco_map.get(t.get("recommendation"),
                                                t.get("recommendation")),
                           "target": tp})
    houses.sort(key=lambda x: -(x["target"] or 0))
    return {
        "reco": reco_map.get(cons.get("recommendation"), cons.get("recommendation")),
        "target": _q(cons.get("consensus")),
        "current": _q(cons.get("currentPrice")),
        "upside_pct": _q(cons.get("priceChangeRel")),
        "houses_count": len(houses),
        "houses_top": houses[:4],
    }


async def next_dividend(instrument_uid: str) -> dict | None:
    """Ближайший ОБЪЯВЛЕННЫЙ дивиденд (отсечка в будущем): сумма, доходность,
    дата отсечки и дней до неё. Критично для гэпа и базиса фьючерса."""
    from datetime import timedelta
    now = datetime.now(timezone.utc)
    try:
        r = await _post("tinkoff.public.invest.api.contract.v1."
                        "InstrumentsService/GetDividends",
                        {"instrumentId": instrument_uid,
                         "from": _iso(now),
                         "to": _iso(now + timedelta(days=365))})
    except Exception as e:
        logger.warning("next_dividend: %s", str(e)[:90])
        return None
    best = None
    today = _iso(now)[:10]
    for d in (r.get("dividends") or []):
        rec = d.get("recordDate") or ""
        if not rec or rec[:10] < today:   # API иногда отдаёт прошедшие — фильтруем сами
            continue
        if best is None or rec < best.get("record_date", "9999"):
            best = {"value": _q(d.get("dividendNet")),
                    "currency": (d.get("dividendNet") or {}).get("currency"),
                    "record_date": rec,
                    "yield_pct": _q(d.get("yieldValue"))}
    if best:
        try:
            rd = datetime.fromisoformat(best["record_date"].replace("Z", "+00:00"))
            best["days_to_record"] = max(0, (rd - now).days)
        except Exception:
            best["days_to_record"] = None
    return best


async def tech(instrument_uid: str, indicator: str, length: int = 14,
               interval: str = "1h", days_back: int = 30) -> list[dict] | None:
    itype = _TECH.get(indicator)
    if not itype:
        return None
    iv = _IND_INTERVAL.get(interval, "INDICATOR_INTERVAL_ONE_HOUR")
    to = datetime.now(timezone.utc)
    frm = to - timedelta(days=days_back)
    body = {
        "indicatorType": itype, "instrumentUid": instrument_uid,
        "from": _iso(frm), "to": _iso(to), "interval": iv,
        "typeOfPrice": "TYPE_OF_PRICE_CLOSE", "length": length,
    }
    if indicator == "MACD":
        body.update({"smoothing": {"fastLength": 12, "slowLength": 26,
                                   "signalSmoothing": 9}})
    if indicator == "BB":
        body.update({"deviation": {"deviationMultiplier": {"units": 2, "nano": 0}}})
    try:
        d = await _post(f"{MD}/GetTechAnalysis", body)
    except Exception:
        return None
    out = []
    for r in d.get("technicalIndicators", []):
        item = {"t": r.get("timestamp")}
        for k in ("signal", "macd", "middleBand", "upperBand", "lowerBand"):
            if k in r:
                item[k] = round(_q(r[k]), 4)
        out.append(item)
    return out[-3:] if out else None


async def futures_margin(instrument_id: str) -> dict | None:
    try:
        d = await _post(f"{INS}/GetFuturesMargin", {"instrumentId": instrument_id})
    except Exception:
        return None
    return {
        "margin_buy": round(_q(d.get("initialMarginOnBuy")), 2),
        "margin_sell": round(_q(d.get("initialMarginOnSell")), 2),
        "min_price_increment": _q(d.get("minPriceIncrement")),
        "min_price_increment_amount": _q(d.get("minPriceIncrementAmount")),
    }


USERS = "tinkoff.public.invest.api.contract.v1.UsersService"
OPS = "tinkoff.public.invest.api.contract.v1.OperationsService"


async def accounts() -> list[dict] | None:
    """Список счетов владельца (GetAccounts). Нужен, чтобы бот знал, НА КАКОМ
    счёте и СКОЛЬКО денег. Только чтение. Нет токена → None."""
    if not enabled():
        return None
    try:
        d = await _post(f"{USERS}/GetAccounts", {})
    except Exception:                                       # noqa: BLE001
        return None
    out = []
    for a in d.get("accounts", []):
        out.append({"id": a.get("id"), "name": a.get("name"),
                    "type": a.get("type"), "status": a.get("status")})
    return out


async def portfolio(account_id: str) -> dict | None:
    """Портфель счёта (GetPortfolio): бот ВИДИТ реальный баланс — сколько
    свободных рублей, стоимость позиций, ГО. Это ответ на «шарит ли он про
    сумму денег»: да, размер позиции считается от РЕАЛЬНОГО депозита, а не
    от выдуманного числа (NO DUMMIES). Только чтение. Нет данных → None."""
    if not (enabled() and account_id):
        return None
    try:
        d = await _post(f"{OPS}/GetPortfolio",
                        {"accountId": account_id, "currency": "RUB"})
    except Exception:                                       # noqa: BLE001
        return None
    total = _q(d.get("totalAmountPortfolio"))
    free = 0.0
    for m in (d.get("totalAmountCurrencies"), d.get("totalAmountMoney")):
        if isinstance(m, dict):
            free += _q(m)
    # свободные рубли из позиций-валют
    for p in d.get("positions", []):
        if p.get("instrumentType") == "currency" and (p.get("figi", "").startswith("RUB")
                                                       or p.get("ticker") == "RUB"):
            free = _q(p.get("quantity"))
    return {
        "total_rub": round(total, 2),
        "free_rub": round(free, 2),
        "expected_yield_pct": round(_q(d.get("expectedYield")), 2),
        "positions": [{"figi": p.get("figi"), "type": p.get("instrumentType"),
                       "qty": _q(p.get("quantity")),
                       "cur_price": _q(p.get("currentPrice"))}
                      for p in d.get("positions", [])],
        "note": "реальный баланс счёта — размер позиции считается от него",
    }


async def dividends(instrument_id: str) -> list[dict] | None:
    to = datetime.now(timezone.utc) + timedelta(days=180)
    frm = datetime.now(timezone.utc) - timedelta(days=400)
    try:
        d = await _post(f"{INS}/GetDividends",
                        {"instrumentId": instrument_id, "from": _iso(frm), "to": _iso(to)})
    except Exception:
        return None
    out = []
    for dv in d.get("dividends", []):
        out.append({
            "value": round(_q(dv.get("dividendNet")), 4),
            "record_date": dv.get("recordDate"),
            "payment_date": dv.get("paymentDate"),
            "yield": round(_q(dv.get("yieldValue")), 3),
        })
    return out[-6:] if out else None


async def fundamentals(asset_uid: str) -> dict | None:
    """Фундаментальные показатели акции (P/E, капитализация, дивдоходность,
    рентабельность и т.д.) через GetAssetFundamentals. Нужен asset_uid."""
    if not asset_uid:
        return None
    try:
        d = await _post(f"{INS}/GetAssetFundamentals", {"assets": [asset_uid]})
    except Exception:
        return None
    arr = d.get("fundamentals") or []
    if not arr:
        return None
    f = arr[0]

    def num(*keys):
        for k in keys:
            v = f.get(k)
            if v not in (None, "", 0, 0.0):
                return v
        return None

    out = {
        "market_cap": num("marketCapitalization"),
        "pe_ttm": num("peRatioTtm", "peRatio"),
        "pb": num("priceToBookTtm", "pbRatio"),
        "ps_ttm": num("priceToSalesTtm"),
        "ev_ebitda": num("evToEbitdaMrq", "evToEbitda"),
        "roe": num("roe"),
        "roa": num("roa"),
        "eps_ttm": num("epsTtm", "dilutedEpsTtm"),
        "revenue_ttm": num("revenueTtm"),
        "ebitda_ttm": num("ebitdaTtm"),
        "net_income_ttm": num("netIncomeTtm"),
        "div_yield_ttm": num("dividendYieldDailyTtm"),
        "div_rate_ttm": num("dividendRateTtm"),
        "beta": num("beta"),
        "free_float": num("freeFloat"),
        "high_52w": num("highPriceLast52Weeks"),
        "low_52w": num("lowPriceLast52Weeks"),
        "shares_out": num("sharesOutstanding"),
        "currency": f.get("currency"),
    }
    out = {k: v for k, v in out.items() if v is not None}
    return out or None


# ──────────────────────────────────────────────────────────────────────
# Локальные индикаторы из свечей
# ──────────────────────────────────────────────────────────────────────

def _ema(values: list[float], period: int) -> float | None:
    if len(values) < period:
        return None
    k = 2 / (period + 1)
    e = sum(values[:period]) / period
    for v in values[period:]:
        e = v * k + e * (1 - k)
    return round(e, 6)


def _rsi(closes: list[float], period: int = 14) -> float | None:
    if len(closes) < period + 1:
        return None
    gains = losses = 0.0
    for i in range(1, period + 1):
        ch = closes[i] - closes[i - 1]
        gains += max(ch, 0)
        losses += max(-ch, 0)
    avg_g = gains / period
    avg_l = losses / period
    for i in range(period + 1, len(closes)):
        ch = closes[i] - closes[i - 1]
        avg_g = (avg_g * (period - 1) + max(ch, 0)) / period
        avg_l = (avg_l * (period - 1) + max(-ch, 0)) / period
    if avg_l == 0:
        return 100.0
    rs = avg_g / avg_l
    return round(100 - 100 / (1 + rs), 2)


def _atr(cnd: list[dict], period: int = 14) -> float | None:
    if len(cnd) < period + 1:
        return None
    trs = []
    for i in range(1, len(cnd)):
        h, l, pc = cnd[i]["h"], cnd[i]["l"], cnd[i - 1]["c"]
        trs.append(max(h - l, abs(h - pc), abs(l - pc)))
    return round(sum(trs[-period:]) / period, 6)


def _vol_annualized(closes: list[float], window: int = 20) -> float | None:
    if len(closes) < window + 1:
        return None
    rets = [math.log(closes[i] / closes[i - 1])
            for i in range(len(closes) - window, len(closes)) if closes[i - 1] > 0]
    if len(rets) < 2:
        return None
    mean = sum(rets) / len(rets)
    var = sum((r - mean) ** 2 for r in rets) / (len(rets) - 1)
    return round(math.sqrt(var) * math.sqrt(252) * 100, 2)


def daily_metrics(daily: list[dict]) -> dict:
    if not daily:
        return {}
    closes = [c["c"] for c in daily]
    last = closes[-1]
    prev = closes[-2] if len(closes) > 1 else last
    hi20 = max(c["h"] for c in daily[-20:]) if len(daily) >= 1 else None
    lo20 = min(c["l"] for c in daily[-20:]) if len(daily) >= 1 else None
    hi52 = max(c["h"] for c in daily) if daily else None
    lo52 = min(c["l"] for c in daily) if daily else None
    avg_vol20 = round(sum(c["v"] for c in daily[-20:]) / min(20, len(daily)), 0)
    return {
        "last_close": last,
        "prev_close": prev,
        "day_change_pct": round((last - prev) / prev * 100, 2) if prev else None,
        "ema9": _ema(closes, 9), "ema21": _ema(closes, 21),
        "ema50": _ema(closes, 50), "ema200": _ema(closes, 200),
        "rsi14": _rsi(closes, 14), "atr14": _atr(daily, 14),
        "vol_annual_pct": _vol_annualized(closes, 20),
        "high_20d": round(hi20, 6) if hi20 else None,
        "low_20d": round(lo20, 6) if lo20 else None,
        "high_range": round(hi52, 6) if hi52 else None,
        "low_range": round(lo52, 6) if lo52 else None,
        "dist_to_high20_pct": round((hi20 - last) / last * 100, 2) if (hi20 and last) else None,
        "dist_to_low20_pct": round((last - lo20) / last * 100, 2) if (lo20 and last) else None,
        "avg_volume_20d": avg_vol20,
        "above_ema50": (last > _ema(closes, 50)) if _ema(closes, 50) else None,
        "above_ema200": (last > _ema(closes, 200)) if _ema(closes, 200) else None,
    }


def intraday_metrics(intra: list[dict]) -> dict:
    if not intra:
        return {}
    # «сегодня» = свечи последней календарной даты
    last_date = (intra[-1]["t"] or "")[:10]
    today = [c for c in intra if (c["t"] or "")[:10] == last_date]
    if not today:
        today = intra[-78:]
    pv = sum(((c["h"] + c["l"] + c["c"]) / 3) * c["v"] for c in today)
    vv = sum(c["v"] for c in today)
    vwap = round(pv / vv, 6) if vv else None
    o = today[0]["o"]
    last = today[-1]["c"]
    hi = max(c["h"] for c in today)
    lo = min(c["l"] for c in today)
    return {
        "session_date": last_date,
        "session_open": o, "session_last": last,
        "session_high": hi, "session_low": lo,
        "session_range_pct": round((hi - lo) / o * 100, 2) if o else None,
        "session_change_pct": round((last - o) / o * 100, 2) if o else None,
        "vwap": vwap,
        "vs_vwap_pct": round((last - vwap) / vwap * 100, 2) if vwap else None,
        "session_volume": vv,
        "n_bars": len(today),
    }


# ──────────────────────────────────────────────────────────────────────
# ГЛАВНОЕ: собрать полное досье
# ──────────────────────────────────────────────────────────────────────

async def collect_dossier(ticker: str, asset_class: str) -> dict:
    """Полное досье инструмента из Tinkoff. asset_class: share|futures|currency."""
    dossier: dict = {"ticker": ticker, "asset_class": asset_class,
                     "source": "tinkoff", "collected_at": _iso(datetime.now(timezone.utc)),
                     "errors": []}
    inst = None
    try:
        inst = await resolve(ticker, asset_class)
    except Exception as e:
        dossier["errors"].append(f"resolve: {str(e)[:80]}")
    if not inst:
        dossier["errors"].append("инструмент не найден в Tinkoff")
        return dossier

    figi = inst.get("figi") or inst.get("uid")
    uid = inst.get("uid") or figi
    dossier["instrument"] = {
        "name": inst.get("name"),
        "ticker": inst.get("ticker"),
        "figi": figi, "uid": uid,
        "class_code": inst.get("classCode"),
        "currency": inst.get("currency"),
        "lot": inst.get("lot"),
        "sector": inst.get("sector"),
        "exchange": inst.get("exchange"),
        "country": inst.get("countryOfRisk"),
        "expiration": inst.get("expirationDate"),
        "basic_asset": inst.get("basicAsset"),
        "basic_asset_size": _q(inst.get("basicAssetSize")) or None,
        "min_price_increment": _q(inst.get("minPriceIncrement")) or None,
        "nominal": _q(inst.get("nominal")) or None,
        "first_trade": inst.get("first1minCandleDate"),
        "asset_uid": inst.get("assetUid") or inst.get("asset_uid"),
    }

    # Параллельные блоки
    tasks = {
        "last": last_price(figi),
        "status": trading_status(figi),
        "ob": orderbook(figi, depth=50),
        "tape": last_trades(figi, minutes=90),
        "intraday": candles(figi, "5m", 3),
        "hourly": candles(figi, "1h", 14),
        # 200 календарных дней ≈ 138 торговых — этого НЕ хватало на EMA200
        # (нужно ≥200 сессий), и ema200/above_ema200 были вечно None. 400 дн ≈
        # 275 сессий — EMA200 наконец считается.
        "daily": candles(figi, "1d", 400),
    }
    if uid:
        tasks["rsi_tech"] = tech(uid, "RSI", 14, "1h", 20)
        tasks["macd_tech"] = tech(uid, "MACD", 12, "1h", 30)
    if asset_class == "futures":
        tasks["margin"] = futures_margin(figi)
    if asset_class == "share":
        tasks["dividends"] = dividends(figi)
        _auid = inst.get("assetUid") or inst.get("asset_uid")
        if _auid:
            tasks["fundamentals"] = fundamentals(_auid)

    results = await asyncio.gather(*tasks.values(), return_exceptions=True)
    res = dict(zip(tasks.keys(), results))

    def ok(key):
        v = res.get(key)
        if isinstance(v, Exception):
            dossier["errors"].append(f"{key}: {str(v)[:60]}")
            return None
        return v

    last = ok("last")
    dossier["price"] = last
    _fund = ok("fundamentals")
    if _fund:
        dossier["fundamentals"] = _fund
    dossier["trading_status"] = ok("status")
    dossier["orderbook"] = ok("ob")
    dossier["tape"] = ok("tape")

    intra = ok("intraday") or []
    hourly = ok("hourly") or []
    daily = ok("daily") or []
    dossier["candles_intraday_5m"] = intra[-120:]   # ~2 дня 5-мин
    dossier["candles_hourly"] = hourly[-80:]
    dossier["candles_daily_tail"] = daily[-60:]     # для ИИ — хвост
    dossier["daily_metrics"] = daily_metrics(daily)
    dossier["intraday_metrics"] = intraday_metrics(intra)

    tech_block = {}
    rsi_t = ok("rsi_tech")
    macd_t = ok("macd_tech")
    if rsi_t:
        tech_block["rsi_tinkoff"] = rsi_t
    if macd_t:
        tech_block["macd_tinkoff"] = macd_t
    if tech_block:
        dossier["tinkoff_tech"] = tech_block

    if asset_class == "futures":
        dossier["margin"] = ok("margin")
    if asset_class == "share":
        dv = ok("dividends")
        if dv:
            dossier["dividends"] = dv

    return dossier
