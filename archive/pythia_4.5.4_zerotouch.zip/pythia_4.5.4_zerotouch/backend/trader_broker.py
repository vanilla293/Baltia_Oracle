# -*- coding: utf-8 -*-
"""ОРАКУЛ // ПИФИЯ — БРОКЕР-ИСПОЛНИТЕЛЬ (руки Фармилы).

Money-touching спина всего торгового бота. Всё, что реально двигает деньги,
проходит ТОЛЬКО здесь — один узкий, проверяемый, залоггированный шлюз.

ТРИ РЕЖИМА (MODE), безопасность нарастает СНИЗУ ВВЕРХ:
  · "dry"     — СУХОЙ ПРОГОН (по умолчанию): ордер НЕ уходит в сеть, только
                считается и пишется в аудит-лог. Так стартует бот ВСЕГДА при
                первом запуске — баг на первой минуте не тронет счёт.
  · "sandbox" — ПЕСОЧНИЦА Tinkoff: виртуальные деньги, реальный рынок и стакан.
                Обкатка Хищника без риска для депозита.
  · "real"    — БОЕВОЙ счёт, реальные деньги. Вооружается ТОЛЬКО явно:
                env TRADER_ARM_REAL=1 И переданный arm_token (двойной рубильник).
                Иначе брокер честно откатывается в "dry" и пишет причину.

Инвариант: real НЕ включится молча ни при каком стечении обстоятельств —
нет двойного подтверждения → dry. NO DUMMIES: нет токена/счёта → честный отказ.
Каждый интент и результат ордера пишется в audit jsonl (кто/что/когда/цена/итог).
Сеть тут ЗАКОННА — это исполнение на бирже, не расчёт неба.
"""
from __future__ import annotations

import json
import os
import time
from pathlib import Path

from . import config, tinkoff

SANDBOX = "tinkoff.public.invest.api.contract.v1.SandboxService"
ORDERS = "tinkoff.public.invest.api.contract.v1.OrdersService"
OPER = "tinkoff.public.invest.api.contract.v1.OperationsService"
STOPS = "tinkoff.public.invest.api.contract.v1.StopOrdersService"

MODES = ("dry", "sandbox", "real")
_AUDIT_PATH = config.DATA_DIR / "trader_audit.jsonl"

BUY, SELL = "ORDER_DIRECTION_BUY", "ORDER_DIRECTION_SELL"
MARKET, LIMIT = "ORDER_TYPE_MARKET", "ORDER_TYPE_LIMIT"
STOP_BUY = "STOP_ORDER_DIRECTION_BUY"
STOP_SELL = "STOP_ORDER_DIRECTION_SELL"


def _now() -> float:
    return time.time()


def _q_to_float(q) -> float:
    """Quotation/MoneyValue → float (units + nano/1e9)."""
    if not isinstance(q, dict):
        return 0.0
    return float(q.get("units", 0) or 0) + float(q.get("nano", 0) or 0) / 1e9


def _to_quotation(x: float) -> dict:
    """float → Quotation {units, nano}."""
    units = int(x)
    nano = int(round((x - units) * 1e9))
    return {"units": units, "nano": nano}


def _audit(kind: str, payload: dict) -> None:
    """Каждое движение денег — в несбиваемый журнал (append-only)."""
    rec = {"ts": _now(), "kind": kind, **payload}
    try:
        with open(_AUDIT_PATH, "a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    except Exception:                                       # noqa: BLE001
        pass                                                # журнал не должен ронять торговлю


class Broker:
    """Единый шлюз ордеров. Инъекция _post позволяет тестировать без сети."""

    def __init__(self, mode: str = "dry", account_id: str | None = None,
                 arm_token: str | None = None, poster=None):
        self.requested_mode = mode if mode in MODES else "dry"
        self.mode = self._resolve_mode(self.requested_mode, arm_token)
        self.account_id = account_id
        self._post = poster or tinkoff._post          # инъекция для тестов
        self.blocked_reason: str | None = None
        _audit("broker_init", {"requested": self.requested_mode,
                               "effective": self.mode,
                               "account": account_id})

    # ── боевой режим ───────────────────────────────────────────────────────
    @staticmethod
    def _resolve_mode(mode: str, arm_token: str | None) -> str:
        """Боевой real разрешён, когда есть токен Тинькофф (право торговли).
        По прямому требованию владельца доп-рубильники в конфигах убраны: ввёл
        ключ — сразу боевой. Отключить боевой можно env PYTHIA_DRY=1 (страховка
        для теста). Нет токена → dry (торговать нечем)."""
        if mode != "real":
            return mode
        if os.getenv("PYTHIA_DRY", "") == "1":
            _audit("real_refused", {"note": "PYTHIA_DRY=1 — принудительный dry"})
            return "dry"
        if not tinkoff.enabled():
            _audit("real_refused", {"note": "нет токена Тинькофф — откат в dry"})
            return "dry"
        return "real"

    def is_live(self) -> bool:
        """Ордера реально уходят в сеть? (sandbox или real, не dry)."""
        return self.mode in ("sandbox", "real")

    def _svc(self) -> str:
        return SANDBOX if self.mode == "sandbox" else ORDERS

    # ── счёт ──────────────────────────────────────────────────────────────
    async def ensure_account(self, pay_in: float = 100000.0) -> dict:
        """Песочница: открыть счёт + пополнить виртуалом. dry/real: только чтение."""
        if self.mode == "dry":
            self.account_id = self.account_id or "DRY-ACCOUNT"
            return {"ok": True, "account": self.account_id, "mode": "dry"}
        if not tinkoff.enabled():
            self.blocked_reason = "нет TINKOFF_TOKEN"
            return {"ok": False, "note": self.blocked_reason}
        try:
            if self.mode == "sandbox":
                accs = await self._post(f"{SANDBOX}/GetSandboxAccounts", {})
                lst = accs.get("accounts") or []
                if lst:
                    self.account_id = lst[0]["id"]
                else:
                    opened = await self._post(f"{SANDBOX}/OpenSandboxAccount", {})
                    self.account_id = opened["accountId"]
                    await self._post(f"{SANDBOX}/SandboxPayIn",
                                     {"accountId": self.account_id,
                                      "amount": {"currency": "rub",
                                                 "units": int(pay_in), "nano": 0}})
                return {"ok": True, "account": self.account_id, "mode": "sandbox"}
            # real: счёт задаёт владелец, сами не открываем
            if not self.account_id:
                self.blocked_reason = "боевой accountId не задан"
                return {"ok": False, "note": self.blocked_reason}
            return {"ok": True, "account": self.account_id, "mode": "real"}
        except Exception as e:                              # noqa: BLE001
            self.blocked_reason = str(e)[:160]
            _audit("account_error", {"err": self.blocked_reason})
            return {"ok": False, "note": self.blocked_reason}

    async def portfolio(self) -> dict:
        """Свободные деньги, позиции, ГО. dry → пустой честный портфель."""
        if self.mode == "dry":
            return {"cash": None, "positions": [], "mode": "dry",
                    "note": "сухой прогон — реального портфеля нет"}
        try:
            if self.mode == "sandbox":
                p = await self._post(f"{SANDBOX}/GetSandboxPortfolio",
                                     {"accountId": self.account_id})
            else:
                p = await self._post(f"{OPER}/GetPortfolio",
                                     {"accountId": self.account_id})
            cash = _q_to_float(p.get("totalAmountCurrencies"))
            poss = [{"figi": x.get("figi"),
                     "qty": _q_to_float(x.get("quantity")),
                     "avg": _q_to_float(x.get("averagePositionPrice")),
                     "yield": _q_to_float(x.get("expectedYield"))}
                    for x in (p.get("positions") or [])]
            return {"cash": cash, "positions": poss, "mode": self.mode}
        except Exception as e:                              # noqa: BLE001
            return {"cash": None, "positions": [], "error": str(e)[:160]}

    # ── ордер ─────────────────────────────────────────────────────────────
    async def place(self, figi: str, direction: str, lots: int,
                    price: float | None = None, tag: str = "") -> dict:
        """Выставить ордер. lots — ЦЕЛОЕ число лотов (>0). price=None → рыночный.
        dry → только считаем и логируем, в сеть не уходим (NO DUMMIES)."""
        assert direction in (BUY, SELL), "direction"
        lots = int(lots)
        if lots <= 0:
            return {"ok": False, "note": "lots<=0 — ордер не выставлен"}
        otype = MARKET if price is None else LIMIT
        order_id = f"px-{int(_now()*1000)}-{tag or 'o'}"
        intent = {"figi": figi, "direction": direction, "lots": lots,
                  "price": price, "type": otype, "tag": tag,
                  "mode": self.mode, "order_id": order_id}
        _audit("order_intent", intent)
        if self.mode == "dry":
            return {"ok": True, "dry": True, "order_id": order_id, **intent,
                    "note": "сухой прогон — ордер посчитан, в сеть НЕ ушёл"}
        if not self.account_id:
            return {"ok": False, "note": "нет accountId — ордер не выставлен"}
        body = {"accountId": self.account_id, "instrumentId": figi,
                "quantity": lots, "direction": direction,
                "orderType": otype, "orderId": order_id}
        if price is not None:
            body["price"] = _to_quotation(price)
        try:
            r = await self._post(f"{self._svc()}/Post{'Sandbox' if self.mode=='sandbox' else ''}Order",
                                 body)
            res = {"ok": True, "order_id": r.get("orderId", order_id),
                   "status": r.get("executionReportStatus"),
                   "exec_lots": r.get("lotsExecuted"), **intent}
            _audit("order_done", res)
            return res
        except Exception as e:                              # noqa: BLE001
            res = {"ok": False, "error": str(e)[:160], **intent}
            _audit("order_error", res)
            return res

    async def order_state(self, order_id: str) -> dict:
        """Судьба ордера: реально ли исполнен. Реальный трейдер НЕ считает
        лимитку исполненной по факту выставления. dry → исполнен сразу."""
        if self.mode == "dry":
            return {"ok": True, "filled": True, "dry": True}
        if not self.account_id:
            return {"ok": False, "note": "нет accountId"}
        try:
            r = await self._post(
                f"{self._svc()}/Get{'Sandbox' if self.mode == 'sandbox' else ''}OrderState",
                {"accountId": self.account_id, "orderId": order_id})
            st = str(r.get("executionReportStatus", ""))
            return {"ok": True, "status": st,
                    "filled": st.endswith("_FILL") or st == "FILL",
                    "exec_lots": r.get("lotsExecuted")}
        except Exception as e:                              # noqa: BLE001
            return {"ok": False, "error": str(e)[:120]}

    async def cancel(self, order_id: str) -> dict:
        """Снять невыполненный лимит (цена ушла / таймаут)."""
        _audit("order_cancel", {"order_id": order_id, "mode": self.mode})
        if self.mode == "dry":
            return {"ok": True, "dry": True}
        if not self.account_id:
            return {"ok": False, "note": "нет accountId"}
        try:
            await self._post(
                f"{self._svc()}/Cancel{'Sandbox' if self.mode == 'sandbox' else ''}Order",
                {"accountId": self.account_id, "orderId": order_id})
            return {"ok": True}
        except Exception as e:                              # noqa: BLE001
            return {"ok": False, "error": str(e)[:120]}

    # ── АППАРАТНЫЙ СТОП НА СЕРВЕРЕ БИРЖИ (спринт «Хищник», прокол №4) ──────
    async def place_stop(self, figi: str, direction: str, lots: int,
                         stop_price: float, tag: str = "hw-stop") -> dict:
        """Stop-market НА СЕРВЕРЕ БИРЖИ: триггер лежит у биржи ДО импульса,
        срабатывает даже если бот мёртв, пинг упал, контейнер убит.

        direction — направление ЗАКРЫВАЮЩЕЙ заявки (long закрывает SELL).
        Только real: StopOrdersService не существует в песочнице Tinkoff —
        dry/sandbox честно отвечают virtual=True (стоп остаётся у бота)."""
        assert direction in (BUY, SELL), "direction"
        lots = int(lots)
        if lots <= 0 or not stop_price or stop_price <= 0:
            return {"ok": False, "note": "lots<=0 или нет stop_price"}
        intent = {"figi": figi, "direction": direction, "lots": lots,
                  "stop_price": stop_price, "mode": self.mode, "tag": tag}
        _audit("stop_intent", intent)
        if self.mode != "real":
            return {"ok": True, "virtual": True, **intent,
                    "note": ("режим " + self.mode + ": биржевых стопов нет — "
                             "стоп виртуальный, у бота (честно)")}
        if not self.account_id:
            return {"ok": False, "note": "нет accountId — стоп не выставлен"}
        body = {"accountId": self.account_id, "instrumentId": figi,
                "quantity": lots,
                "direction": STOP_BUY if direction == BUY else STOP_SELL,
                "stopPrice": _to_quotation(stop_price),
                "stopOrderType": "STOP_ORDER_TYPE_STOP_LOSS",
                "expirationType": "STOP_ORDER_EXPIRATION_TYPE_GOOD_TILL_CANCEL",
                "exchangeOrderType": "EXCHANGE_ORDER_TYPE_MARKET"}
        try:
            r = await self._post(f"{STOPS}/PostStopOrder", body)
            res = {"ok": True, "stop_order_id": r.get("stopOrderId"), **intent}
            _audit("stop_done", res)
            return res
        except Exception as e:                              # noqa: BLE001
            res = {"ok": False, "error": str(e)[:160], **intent}
            _audit("stop_error", res)
            return res

    async def cancel_stop(self, stop_order_id: str) -> dict:
        """Снять биржевой стоп (перенос уровня / закрытие позиции)."""
        _audit("stop_cancel", {"stop_order_id": stop_order_id, "mode": self.mode})
        if self.mode != "real":
            return {"ok": True, "virtual": True}
        if not self.account_id or not stop_order_id:
            return {"ok": False, "note": "нет accountId/stop_order_id"}
        try:
            await self._post(f"{STOPS}/CancelStopOrder",
                             {"accountId": self.account_id,
                              "stopOrderId": stop_order_id})
            return {"ok": True}
        except Exception as e:                              # noqa: BLE001
            return {"ok": False, "error": str(e)[:120]}

    async def stop_orders(self) -> list:
        """Живые биржевые стопы счёта (сверка/чистка сирот)."""
        if self.mode != "real" or not self.account_id:
            return []
        try:
            r = await self._post(f"{STOPS}/GetStopOrders",
                                 {"accountId": self.account_id})
            return r.get("stopOrders") or []
        except Exception:                                   # noqa: BLE001
            return []

    async def flat_all(self, positions: list | None = None) -> dict:
        """ПАНИКА: закрыть все позиции по рынку. Killswitch зовёт это."""
        if self.mode == "dry":
            _audit("flat_all", {"mode": "dry"})
            return {"ok": True, "dry": True, "closed": 0}
        port = {"positions": positions} if positions is not None else await self.portfolio()
        closed = 0
        for p in (port.get("positions") or []):
            qty = p.get("qty") or 0
            if abs(qty) < 1e-9 or not p.get("figi"):
                continue
            d = SELL if qty > 0 else BUY
            await self.place(p["figi"], d, int(abs(qty)), price=None, tag="PANIC")
            closed += 1
        _audit("flat_all", {"mode": self.mode, "closed": closed})
        return {"ok": True, "closed": closed}


# ── self-test: вся логика без единого сетевого запроса (fake poster) ─────────
if __name__ == "__main__":
    import asyncio

    calls = []

    async def fake_post(path, body, timeout=15.0):
        calls.append((path, body))
        if path.endswith("GetSandboxAccounts"):
            return {"accounts": []}
        if path.endswith("OpenSandboxAccount"):
            return {"accountId": "SB-1"}
        if path.endswith("SandboxPayIn"):
            return {"balance": {"units": 100000}}
        if "Portfolio" in path:
            return {"totalAmountCurrencies": {"units": 98000, "nano": 0},
                    "positions": [{"figi": "SIU5", "quantity": {"units": 3},
                                   "averagePositionPrice": {"units": 90, "nano": 0},
                                   "expectedYield": {"units": 120}}]}
        if "Order" in path:
            return {"orderId": body.get("orderId"), "executionReportStatus": "FILL",
                    "lotsExecuted": body.get("quantity")}
        return {}

    async def main():
        # 1) DRY по умолчанию — ордер НЕ уходит в сеть
        b = Broker(mode="dry", poster=fake_post)
        assert b.mode == "dry" and not b.is_live()
        r = await b.place("SIU5", BUY, 2, tag="recon")
        assert r["ok"] and r["dry"] and not calls, "dry не должен слать в сеть"

        # 2) real БЕЗ токена Тинькофф → откат в dry (торговать нечем)
        _tok = tinkoff.config.TINKOFF_TOKEN
        tinkoff.config.TINKOFF_TOKEN = ""
        os.environ.pop("PYTHIA_DRY", None)
        b2 = Broker(mode="real", poster=fake_post)
        assert b2.mode == "dry", "real без токена обязан откатиться в dry"

        # 3) real С токеном → сразу боевой; PYTHIA_DRY=1 — принудительный dry
        tinkoff.config.TINKOFF_TOKEN = "t.test"
        b3 = Broker(mode="real", account_id="ACC", poster=fake_post)
        assert b3.mode == "real" and b3.is_live()
        os.environ["PYTHIA_DRY"] = "1"
        assert Broker(mode="real", poster=fake_post).mode == "dry"
        os.environ.pop("PYTHIA_DRY", None)

        # 3b) судьба ордера и снятие: dry исполнен сразу; real — по статусу биржи
        assert (await b.order_state("x"))["filled"] is True          # dry
        st3 = await b3.order_state("px-1")
        assert st3["ok"] and st3["filled"] is True                   # fake: FILL
        assert (await b3.cancel("px-1"))["ok"]
        tinkoff.config.TINKOFF_TOKEN = _tok

        # 4) sandbox: счёт открывается и пополняется, ордер уходит
        #    (токен ставим фейковый: self-тест не должен зависеть от окружения)
        calls.clear()
        tinkoff.config.TINKOFF_TOKEN = "t.test"
        sb = Broker(mode="sandbox", poster=fake_post)
        acc = await sb.ensure_account(100000)
        assert acc["ok"] and sb.account_id == "SB-1"
        assert any("OpenSandboxAccount" in p for p, _ in calls)
        assert any("SandboxPayIn" in p for p, _ in calls)
        pf = await sb.portfolio()
        assert abs(pf["cash"] - 98000) < 1e-6 and pf["positions"][0]["figi"] == "SIU5"
        od = await sb.place("SIU5", BUY, 3, tag="load")
        assert od["ok"] and any("PostSandboxOrder" in p for p, _ in calls)

        # 5) паника закрывает все позиции встречным направлением
        calls.clear()
        res = await sb.flat_all([{"figi": "SIU5", "qty": 3}])
        assert res["closed"] == 1
        assert calls[0][1]["direction"] == SELL and calls[0][1]["quantity"] == 3

        # 6) lots<=0 не выставляется
        assert (await sb.place("SIU5", BUY, 0))["ok"] is False

        # 6b) АППАРАТНЫЙ СТОП (прокол №4): real шлёт PostStopOrder со
        #     stop-market; dry/sandbox честно говорят «виртуальный»
        calls.clear()
        tinkoff.config.TINKOFF_TOKEN = "t.test"
        br = Broker(mode="real", account_id="ACC", poster=fake_post)
        rs = await br.place_stop("SIU5", SELL, 3, 89000.0, tag="cat")
        assert rs["ok"], rs
        p_stop, b_stop = [c for c in calls if "PostStopOrder" in c[0]][0]
        assert b_stop["stopOrderType"] == "STOP_ORDER_TYPE_STOP_LOSS"
        assert b_stop["exchangeOrderType"] == "EXCHANGE_ORDER_TYPE_MARKET"
        assert b_stop["direction"] == STOP_SELL and b_stop["quantity"] == 3
        assert (await br.cancel_stop("st-1"))["ok"]
        assert any("CancelStopOrder" in p for p, _ in calls)
        dry_stop = await b.place_stop("SIU5", SELL, 1, 100.0)
        assert dry_stop["ok"] and dry_stop["virtual"], dry_stop
        assert (await b.place_stop("SIU5", SELL, 0, 100.0))["ok"] is False
        tinkoff.config.TINKOFF_TOKEN = _tok

        # 7) Quotation round-trip
        q = _to_quotation(90.755)
        assert q["units"] == 90 and abs(q["nano"] - 755_000_000) < 1000
        assert abs(_q_to_float(q) - 90.755) < 1e-6

        print("trader_broker self-test OK: dry не шлёт, real по токену (PYTHIA_DRY "
              "глушит), судьба ордера/снятие, песочница/ордер/паника/квотация — верны")

    asyncio.run(main())
