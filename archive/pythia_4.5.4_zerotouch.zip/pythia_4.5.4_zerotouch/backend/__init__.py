"""ОРАКУЛ // ПИФИЯ — backend package."""
