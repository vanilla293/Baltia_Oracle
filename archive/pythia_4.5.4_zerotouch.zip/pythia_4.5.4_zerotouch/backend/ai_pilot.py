# -*- coding: utf-8 -*-
"""ОРАКУЛ // ПИФИЯ — ИИ-ПИЛОТ (спринт 4.5: «ИИ рулит, код исполняет»).

Прямой заказ владельца (11.08.2026, личный тест на свои деньги, 18+):
  · огромный анализ → шифровщик отдаёт ИСПОЛНЯЕМЫЙ приказ (exec-блок:
    BUY/SELL, уровень засады, тейк, invalidation). ФЛЕТ ЗАПРЕЩЁН — играем
    агрессивно, «лучше переждать, чем недождать», но в сделку заходим ТОЧНО;
  · код исполняет НА МАКСИМУМ: фьючерс — депозит/ГО (ГО и есть плечо; шорт
    сайзится по ГО продажи), акция — плечо по риск-ставкам Тинькофф
    dlong/dshort из каталога (нет ставок → честно на свои);
  · «мы не ставим лимиток на биржу» — уровень входа (засада) живёт ВНУТРИ
    Пифии; имба-момент (цена в ARM_TICKS тиках) → агрессивная лимитка в
    спред (рыночные входы запрещены — «Абсолют»); не льётся → перевзводы →
    маркет-эйбл лимит по best («точно заходим», но это лимитка, не маркет);
  · при победе (тейк) продаём ВСЁ — и огромный анализ С ЧИСТОГО ЛИСТА;
  · каждые 30 минут ПЕРЕПРОВЕРКА: свежие новости + прошлый вердикт +
    текущая ситуация → ЖДЁМ / ЗАКРЫТЬ / КУПИТЬ_СЕЙЧАС / ПРОДАТЬ_СЕЙЧАС /
    НОВЫЙ_АНАЛИЗ. Решение исполняется кодом немедленно.

ЗАКАЛКА ВЕЕРОМ АГЕНТОВ (11.08.2026, 18 агентов, 90 находок, 7 критических
подтверждено скептиками) — что закрыто по их находкам:
  · маржевой дозор согласован с «максимумом»: порог MAINT_FRAC·ГО и
    ЧАСТИЧНОЕ ужатие до вмещающегося объёма (эталон autopilot), а не
    закрытие всего при −0.04% депозита;
  · двойное закрытие убито: результат снятия троса проверяется; трос не
    снялся (уже исполнен на бирже) → сверка с реальной позицией и закрытие
    ТОЛЬКО фактического остатка — голый разворот невозможен;
  · результат закрывающего ордера проверяется: биржа отбила → позиция
    ОСТАЁТСЯ в учёте и закрытие повторяется, а не исчезает с бумаги;
  · ПАНИКА/killswitch/новый план при заявке в полёте забирают ЧАСТИЧКУ
    (налитые лоты становятся позицией и закрываются/ведутся, не теряются);
  · заявка входа несёт СВОИ тейк/стоп (снимок плана) — гонка «новый план
    поверх летящей заявки» не приклеивает чужие уровни;
  · вход в мёртвую идею запрещён: цена уже за invalidation → входа нет,
    сразу свежий разбор; REJECTED-штурм биржи остановлен бэкоффом;
  · рыночный гейт: пустой/протухший стакан (ночь, аукцион, планка) —
    ни входов, ни перепроверок по замороженной цене;
  · один депозит = ОДИН пилот (двойной счёт денег при пакете тикеров
    отрезан на сервере); конфликт со старой оракульской петлёй закрыт;
  · рестарт: своя позиция сохраняется в data/aipilot_state.json и
    подхватывается после перезапуска (иначе она навсегда «ручная»);
  · killswitch дневной: новый торговый день (МСК) вне позиции — счётчик
    заново, СТОП снимается; цены лимиток/стопов снапятся к шагу цены;
    отказ постановки троса виден владельцу, а не проглатывается.

ТОРМОЗА НЕ ОБСУЖДАЮТСЯ: killswitch SessionRisk, маржевой дозор, биржевой
трос по invalidation, ПАНИКА, изоляция ручных лотов. TIME_KILLSWITCH 600с
здесь осознанно НЕ действует (горизонт — часы; его роль играют 30-мин цикл
и трос).

ЧЕСТНЫЕ ОГРАНИЧЕНИЯ (не скрыто, а сказано): комиссии и проскальзывание в
P/L не моделируются (тариф счёта неизвестен — нулём не врём, суммы это
занижает); P/L рыночного закрытия оценивается по последней цене тика, не по
факту исполнения; экспирация фьючерса в позиции не автоматизирована —
трос и перепроверка остаются единственной защитой, перенос контракта
делает новый разбор.

⚫ Реальные деньги на автомате по решению ИИ — осознанный выбор владельца
(«если сольёт — окей»). Измеренная точность ИИ-голоса на истории 44–49%.
Не сигнал, не обещание прибыли; рынок не предсказуем. Плечо 18+.

Self-тест (без сети): python3 -m backend.ai_pilot
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import time

try:
    from . import tinkoff, trader_broker, trader_risk
except ImportError:                                        # запуск как скрипт
    import tinkoff, trader_broker, trader_risk             # noqa: E401

log = logging.getLogger("pythia.ai_pilot")

TICK_SEC = 1.5                 # шаг петли
REVIEW_SEC = float(os.getenv("PYTHIA_AIP_REVIEW_SEC", "1800"))   # 30 мин
ARM_TICKS = float(os.getenv("PYTHIA_AIP_ARM_TICKS", "5"))  # имба-момент: цена
                               # в N шагах цены от засады → бьём (владелец:
                               # «ещё 4-5 пунктов — ставим покупку/продажу»)
ARM_FRAC = 0.0012              # фолбэк, если шаг цены неизвестен: 0.12% цены
RESERVE_FRAC = float(os.getenv("PYTHIA_AIP_RESERVE", "0.02"))
                               # 2% депозита не закладываем в ГО (физика ГО)
MAINT_FRAC = float(os.getenv("PYTHIA_AIP_MAINT", "0.90"))
                               # дозор: капитал < 90% начального ГО → ужатие.
                               # Согласовано с резервом: при 0.98·ГО на входе
                               # буфер ≈ 12% депозита (≈1.2% цены при плече 10),
                               # т.е. стоп ИИ (invalidation) срабатывает РАНЬШЕ
                               # дозора — дозор страховка, не главный стоп
ENTRY_TTL_SEC = 45.0           # лимитка входа живёт столько — дальше перевзвод
RUN_FRAC = 0.0015              # цена убежала от заявки на 0.15% → перевзвод
MAX_REPRICINGS = 3             # перевзводы агрессивной тени; дальше — маркет-
                               # эйбл лимит по best противоположной стороны
ENTRY_FAIL_MAX = 5             # подряд отказов биржи → план сброшен, реанализ
EMERGENCY_STOP_FRAC = 0.006    # перепроверка без invalidation → аварийный стоп
                               # 0.6% (объявленная политика режима)
RECONCILE_EVERY = 40           # тиков между сверками с биржей (~60с)
BOOK_FRESH_SEC = 180.0         # стакан старше — рынок «мёртв»: ни входов,
                               # ни перепроверок по замороженной картинке
DRIFT_FRAC = 0.01              # решение перепроверки протухло: цена ушла >1%
                               # от снимка → вместо входа новый разбор
PLAN_TTL_SEC = float(os.getenv("PYTHIA_AIP_PLAN_TTL", "5400"))
                               # СРОК ЖИЗНИ ПРИКАЗА (1.5 ч): пилот работает
                               # весь день, и засада, выставленная утром, к
                               # вечеру говорит о другом рынке. Протух — не
                               # входим по старой цене, просим свежий разбор
REANALYZE_GAP_SEC = float(os.getenv("PYTHIA_AIP_REANALYZE_GAP", "600"))
                               # не чаще одного огромного анализа в 10 мин:
                               # он стоит пять стадий ИИ, а день длинный

FRAME = ("⚫ ИИ-пилот: реальные деньги на максимум по решению ИИ — личный тест "
         "владельца. Тормоза: killswitch, маржевой дозор, биржевой трос, "
         "ПАНИКА, изоляция ручных лотов. Не сигнал; рынок не предсказуем. 18+")

BUY, SELL = trader_broker.BUY, trader_broker.SELL


def _f(x, d=0.0):
    try:
        if isinstance(x, str):
            x = x.replace(",", ".").strip()
        v = float(x)
        return v if v == v else d
    except (TypeError, ValueError):
        return d


def _q(v) -> float:
    """Quotation Тинькофф {units, nano} → float; число → как есть."""
    if isinstance(v, dict):
        return _f(v.get("units")) + _f(v.get("nano")) / 1e9
    return _f(v)


class AIPilot:
    """Один инструмент — одна петля. ИИ решает, код исполняет на максимум."""

    def __init__(self, base: str, deposit: float | None = None,
                 broker: trader_broker.Broker | None = None):
        self.base = (base or "").upper()
        self.name = self.base
        self.deposit_override = deposit
        self.broker = broker or trader_broker.Broker("real")
        self.asset_class = "share"
        self.figi = None
        self.tick_size = 0.0
        self.point_value = 1.0
        self.go_per_lot: float | None = None   # фьючерс: ГО покупки
        self.go_sell: float | None = None      # фьючерс: ГО продажи (шорт)
        self.dlong = 0.0                       # акция: риск-ставка лонга
        self.dshort = 0.0                      # акция: риск-ставка шорта
        self.deposit = 0.0
        self._live_cash: float | None = None   # свежие деньги счёта (сверка)
        self.session_risk: trader_risk.SessionRisk | None = None
        self._sr_day: int | None = None        # МСК-день killswitch (сброс)
        # план шифровщика: {side, entry|None, take|None, invalidation, why}
        self.plan: dict | None = None
        self.position: dict | None = None      # {side, entry, lots, take,
                                               #  invalidation, opened_ts,
                                               #  stop_id, close_fail?}
        self.pending: dict | None = None       # заявка входа в полёте
                                               # (несёт СВОИ take/invalidation)
        self._cancel_entry = False             # снять заявку ближайшим тиком
        self.foreign_lots = 0                  # ручные лоты владельца
        self.pnls: list[float] = []
        self.prices: list[float] = []
        self.last_book: dict | None = None
        self._book_ts = 0.0
        self.state = "ЖДУ_ПЛАН"
        self.last_action = "—"
        self.review_ts = time.time() + REVIEW_SEC
        self.last_review: dict | None = None
        self._review_busy = False
        self._reanalyzing = False
        self.reanalyze_cb = None               # async () -> None (сервер)
        self._ai_ask_json = None               # инъекция ИИ для self-теста
        self.no_entry_until = 0.0              # бэкофф после отказов биржи
        self._entry_fail = 0
        self.analyses = 0                      # огромных разборов за смену
        self._last_reanalyze_ts = 0.0          # пейсинг дорогих разборов
        self._reanalyze_pending = None         # отложенная просьба о разборе
        self.stopping = False
        self.panic_flag = False
        self._tick_n = 0
        self._stray_warned = False
        self.started_ts = time.time()
        self._state_path = None                # файл выживания позиции
        try:
            try:
                from . import config as _cfg
            except ImportError:
                import config as _cfg
            self._state_path = _cfg.DATA_DIR / "aipilot_state.json"
        except Exception:                                    # noqa: BLE001
            pass

    # ── выживание позиции при рестарте ──────────────────────────────────────
    def _save_state(self) -> None:
        if not self._state_path:
            return
        try:
            if self.position:
                rec = {"figi": self.figi, "base": self.base,
                       "ts": time.time(),
                       "position": {k: self.position.get(k) for k in
                                    ("side", "entry", "lots", "take",
                                     "invalidation", "opened_ts", "stop_id")}}
                self._state_path.write_text(json.dumps(rec, ensure_ascii=False))
            elif self._state_path.exists():
                self._state_path.unlink()
        except Exception as e:                               # noqa: BLE001
            log.warning("state-файл не записался: %s", str(e)[:80])

    def _restore_state(self, portfolio_qty: int) -> None:
        """Рестарт сервера с открытой позицией: подхватить СВОЮ позицию из
        state-файла (иначе она навсегда попала бы в «ручные» и осталась без
        ведения). Подхват только при совпадении figi и знака на счёте."""
        if not (self._state_path and self._state_path.exists()):
            return
        try:
            rec = json.loads(self._state_path.read_text())
        except Exception:                                    # noqa: BLE001
            return
        p = (rec or {}).get("position") or {}
        if rec.get("figi") != self.figi or not p.get("lots"):
            return
        want = int(p["lots"]) * (1 if p.get("side") == "long" else -1)
        if portfolio_qty * want <= 0:      # знак не совпал — позиции уже нет
            try:
                self._state_path.unlink()
            except Exception:                                # noqa: BLE001
                pass
            return
        own = min(abs(portfolio_qty), int(p["lots"]))
        self.position = {"side": p["side"], "entry": _f(p.get("entry")),
                         "lots": own, "take": p.get("take"),
                         "invalidation": p.get("invalidation"),
                         "opened_ts": _f(p.get("opened_ts")) or time.time(),
                         "stop_id": p.get("stop_id"), "floating": 0.0}
        self.foreign_lots = portfolio_qty - (own if p["side"] == "long" else -own)
        self.state = "В_ПОЗИЦИИ"
        self.last_action = (f"РЕСТАРТ: подхватил свою позицию {p['side']} "
                            f"{own} лот @{p.get('entry')} (трос {p.get('stop_id')})")
        log.warning("ИИ-пилот %s: %s", self.base, self.last_action)

    # ── подготовка: контракт, депозит, изоляция, восстановление ─────────────
    async def prepare(self) -> bool:
        accs = await tinkoff.accounts() or []
        acc = accs[0]["id"] if accs else None
        pf = await tinkoff.portfolio(acc) if acc else None
        dep = self.deposit_override
        if dep is None:
            # свободные деньги, не стоимость всего портфеля: максимум считается
            # от денег, которыми реально можно обеспечить ГО (находка веера)
            dep = (pf or {}).get("free_rub")
            if not dep or _f(dep) <= 0:
                dep = (pf or {}).get("total_rub")
                if dep:
                    log.warning("free_rub недоступен — беру total_rub %.0f "
                                "(в нём могут сидеть чужие бумаги)", _f(dep))
        self.deposit = _f(dep)
        if acc:
            self.broker.account_id = acc
        if self.deposit <= 0 and getattr(self.broker, "mode", "dry") != "dry":
            log.error("ИИ-пилот %s: депозит не определён (%.2f) — не стартую "
                      "(сайзинг «на максимум» без денег невозможен)",
                      self.base, self.deposit)
            return False
        try:
            try:
                from . import instruments as _ins
            except ImportError:
                import instruments as _ins
            it = _ins.get(self.base) or {}
            self.asset_class = it.get("asset_class") or self.asset_class
            self.name = it.get("name") or self.base
        except Exception:                                    # noqa: BLE001
            pass
        inst = await tinkoff.resolve(self.base, self.asset_class)
        if not inst:
            log.error("ИИ-пилот: инструмент %s (%s) не найден",
                      self.base, self.asset_class)
            return False
        self.figi = inst.get("figi") or inst.get("uid")
        if self.asset_class == "futures":
            mg = await tinkoff.futures_margin(self.figi) or {}
            self.go_per_lot = mg.get("margin_buy")
            self.go_sell = mg.get("margin_sell")
            inc = mg.get("min_price_increment")
            amt = mg.get("min_price_increment_amount")
            self.point_value = (amt / inc) if inc else 1.0
            self.tick_size = float(inc or 0.0)
            if not self.go_per_lot or self.go_per_lot <= 0:
                log.error("ИИ-пилот %s: ГО фьючерса не получено — сайзинг "
                          "«на максимум» невозможен, не стартую", self.base)
                return False
        else:
            lot = int(inst.get("lot") or 1)
            self.point_value = float(lot)
            self.go_per_lot = None                 # акция: per считается живьём
            # шаг цены акции — из каталога (иначе лимитки некратны шагу)
            self.tick_size = _q(inst.get("minPriceIncrement"))
            # ПЛЕЧО ПО ТИНЬКОФФ (заказ владельца «макс по плечу, если можно»):
            # риск-ставки dlong/dshort из каталога — обеспечение доли позиции.
            # Нет ставок (не маржинальная бумага) → честно на свои (ставка 1).
            self.dlong = _q(inst.get("dlong"))
            self.dshort = _q(inst.get("dshort"))
        # изоляция: всё, что УЖЕ на счёте по этому figi — ручное, не наше…
        qty0 = 0
        for p_ in (pf or {}).get("positions", []):
            if p_.get("figi") == self.figi and abs(p_.get("qty") or 0) >= 1:
                q = p_.get("qty") or 0
                units = abs(q)
                lots = (int(units) if self.asset_class == "futures"
                        else max(1, int(units / max(1.0, self.point_value))))
                qty0 = lots if q > 0 else -lots
                break
        # …кроме СВОЕЙ позиции из прошлой жизни (state-файл, рестарт)
        self._restore_state(qty0)
        if not self.position and qty0:
            self.foreign_lots = qty0
            log.info("ИИ-пилот: ИЗОЛЯЦИЯ ручных лотов владельца %+d (%s)",
                     self.foreign_lots, self.base)
        self.session_risk = trader_risk.SessionRisk(max(1.0, self.deposit))
        self._sr_day = self._msk_day()
        log.info("ИИ-пилот готов: %s figi=%s ГО=%s/%s dlong=%.2f депозит=%.0f "
                 "режим=%s", self.base, self.figi, self.go_per_lot,
                 self.go_sell, self.dlong, self.deposit, self.broker.mode)
        return True

    # ── деньги ──────────────────────────────────────────────────────────────
    @staticmethod
    def _msk_day() -> int:
        return int((time.time() + 3 * 3600) // 86400)

    def _free_cash(self) -> float:
        """Свободные деньги: свежие со сверки, иначе депозит + реализованное."""
        if self._live_cash is not None:
            return self._live_cash
        return self.deposit + sum(self.pnls)

    def per_lot(self, price: float, side: str) -> float:
        """Обеспечение одного лота: фьючерс — ГО стороны; акция — стоимость
        лота × риск-ставка Тинькофф (плечо), нет ставки → на свои."""
        if self.asset_class == "futures":
            if side == "short" and _f(self.go_sell) > 0:
                return _f(self.go_sell)
            return _f(self.go_per_lot)
        notional = _f(price) * max(1.0, _f(self.point_value, 1.0))
        d = self.dlong if side == "long" else self.dshort
        return notional * (d if 0.0 < d <= 1.0 else 1.0)

    def max_lots(self, price: float, side: str | None = None) -> int:
        side = side or (self.plan or {}).get("side") \
            or (self.position or {}).get("side") or "long"
        per = self.per_lot(price, side)
        if per <= 0:
            return 0
        free = self._free_cash()
        free -= abs(self.foreign_lots) * self.per_lot(price, "long")
        lots = int(free * (1.0 - RESERVE_FRAC) // per)
        return max(0, lots)

    def _snap(self, px: float) -> float:
        """Цена — на решётку шага (иначе биржа отбивает некратную лимитку)."""
        t = self.tick_size
        if t and t > 0 and px > 0:
            return round(round(px / t) * t, 10)
        return round(px, 10)

    # ── валидация приказа (стороны уровней — вторая линия после санитайзера) ─
    @staticmethod
    def _plan_valid(side: str, entry, take, inv) -> str | None:
        """None = ок, иначе причина отказа. Для long: inv ниже входа/тейка,
        take выше; short — зеркально. Мусорный приказ не исполняется."""
        inv = _f(inv)
        if inv <= 0:
            return "invalidation не задан или ≤0 — позиции без стопа не бывает"
        e = _f(entry) if entry is not None else None
        t = _f(take) if take is not None else None
        if e is not None and e <= 0:
            return "entry ≤ 0 — мусорная цена"
        if side == "long":
            if e is not None and inv >= e:
                return f"BUY: стоп {inv} НЕ НИЖЕ входа {e}"
            if t is not None and e is not None and t <= e:
                return f"BUY: тейк {t} не выше входа {e}"
            if t is not None and t <= inv:
                return f"BUY: тейк {t} не выше стопа {inv}"
        else:
            if e is not None and inv <= e:
                return f"SELL: стоп {inv} НЕ ВЫШЕ входа {e}"
            if t is not None and e is not None and t >= e:
                return f"SELL: тейк {t} не ниже входа {e}"
            if t is not None and t >= inv:
                return f"SELL: тейк {t} не ниже стопа {inv}"
        return None

    # ── приказ шифровщика (после огромного анализа) ─────────────────────────
    def adopt_forecast(self, forecast: dict | None) -> bool:
        """Свежий прогноз конвейера → боевой план. Возврат: план принят?"""
        self._reanalyzing = False
        if self.session_risk and self.session_risk.locked:
            self.last_action = ("killswitch заблокирован — свежий приказ НЕ "
                                "принят; сброс — новым торговым днём")
            log.warning("ИИ-пилот %s: %s", self.base, self.last_action)
            return False
        ex = (forecast or {}).get("exec") if isinstance(forecast, dict) else None
        if not isinstance(ex, dict) or ex.get("invalidation") is None:
            self.last_action = ("шифровщик не дал исполняемый exec-блок — "
                                "сделки нет, жду следующий разбор (NO DUMMIES)")
            if not self.position:
                self.state = "ЖДУ_ПЛАН"
            # без приказа не спим 30 минут: перепроверка через 5 минут сама
            # решит, просить ли новый разбор
            self.review_ts = min(self.review_ts, time.time() + 300)
            log.warning("ИИ-пилот %s: %s", self.base, self.last_action)
            return False
        side = "long" if str(ex.get("do")).upper() == "BUY" else "short"
        bad = self._plan_valid(side, ex.get("entry"), ex.get("take"),
                               ex.get("invalidation"))
        if bad:
            self.last_action = f"приказ отклонён ({bad}) — жду вменяемый"
            self.review_ts = min(self.review_ts, time.time() + 300)
            log.warning("ИИ-пилот %s: %s", self.base, self.last_action)
            return False
        # позиция ТОЙ ЖЕ стороны: свежий разбор обновляет стоп/тейк позиции
        # (иначе дорогой прогон ИИ ничего не менял — находка веера)
        if self.position and self.position["side"] == side:
            self.position["take"] = ex.get("take")
            self.position["invalidation"] = _f(ex.get("invalidation"))
            self.position["restop"] = True     # перевыставить трос тиком
            self.plan = None
            self._save_state()
            self.last_action = (f"свежий вердикт той же стороны: обновил "
                                f"стоп {self.position['invalidation']} / "
                                f"тейк {self.position['take']}")
            log.info("ИИ-пилот %s: %s", self.base, self.last_action)
            return True
        self.plan = {"side": side, "entry": ex.get("entry"),
                     "take": ex.get("take"),
                     "invalidation": _f(ex.get("invalidation")),
                     "why": str(ex.get("why") or "")[:300], "ts": time.time()}
        if self.pending:                       # заявка старого плана в полёте
            self._cancel_entry = True          # → снять ближайшим тиком
        if not self.position:
            self.state = "ЗАСАДА" if self.plan["entry"] is not None else "ВХОЖУ"
        self.review_ts = time.time() + REVIEW_SEC
        self._entry_fail = 0
        self.last_action = (f"план принят: {side} "
                            + (f"засада @{self.plan['entry']}"
                               if self.plan["entry"] is not None else "вход сразу")
                            + f", тейк {self.plan['take']}, "
                              f"стоп {self.plan['invalidation']}")
        log.info("ИИ-пилот %s: %s (%s)", self.base, self.last_action,
                 self.plan["why"])
        return True

    # ── рыночный гейт: стакан жив и двусторонний? ───────────────────────────
    def _market_alive(self) -> bool:
        b = self.last_book or {}
        if not (_f(b.get("best_bid")) > 0 and _f(b.get("best_ask")) > 0):
            return False
        return (time.time() - self._book_ts) <= BOOK_FRESH_SEC

    def _at_limit(self, side: str, price: float) -> bool:
        """Планка: цена у лимита сессии — вход в лок запрещён."""
        b = self.last_book or {}
        up, dn = _f(b.get("limit_up")), _f(b.get("limit_down"))
        if side == "long" and up > 0 and price >= up * 0.999:
            return True
        if side == "short" and dn > 0 and price <= dn * 1.001:
            return True
        return False

    # ── петля ───────────────────────────────────────────────────────────────
    async def tick(self, price: float, book: dict | None = None) -> None:
        if price and price > 0:
            self.prices.append(float(price))
            if len(self.prices) > 2400:
                del self.prices[:1200]
        if book:
            self.last_book = book
            if _f(book.get("best_bid")) > 0 and _f(book.get("best_ask")) > 0:
                self._book_ts = time.time()
        self._tick_n += 1

        # 0а. новый торговый день (МСК) вне позиции → killswitch заново
        #     (иначе «дневной −6%» копится за всю жизнь пилота — находка веера)
        day = self._msk_day()
        if (self._sr_day is not None and day != self._sr_day
                and not self.position and not self.pending):
            self._sr_day = day
            eq = max(1.0, self._free_cash())
            self.session_risk = trader_risk.SessionRisk(eq)
            self.pnls = []
            if self.state == "СТОП" and not self.panic_flag:
                self.state = "ЖДУ_ПЛАН"
                self.review_ts = min(self.review_ts, time.time() + 300)
            log.info("ИИ-пилот %s: новый торговый день — killswitch заново "
                     "(база %.0f)", self.base, eq)

        # 0б. ТОРМОЗА: killswitch/ПАНИКА выше любых планов
        if self.panic_flag or (self.session_risk and self.session_risk.locked):
            why = ("ПАНИКА владельца" if self.panic_flag else
                   "killswitch: " + str((self.session_risk.state() or {})
                                        .get("reason")))
            part, po = await self._cancel_pending()
            if part > 0 and po:                # частичка — под учёт и закрытие
                await self._absorb_fill(part, po, place_stop=False)
            self.plan = None
            if self.position:
                ok = await self._close_all(price, why, reanalyze=False)
                if not ok:
                    self.last_action = (why + " — закрытие отбито биржей, "
                                        "повторяю каждый тик")
                    return                     # позиция в учёте, добьём дальше
            self.state = "СТОП"
            self.last_action = why + " — торговля остановлена"
            return

        # 1. заявка входа в полёте
        if self.pending:
            await self._pending_tick(price, book)
            return

        # 2. позиция: недобитое закрытие, трос, дозор, тейк, флип
        if self.position:
            pos = self.position
            if pos.get("close_fail"):          # биржа отбила закрытие — добить
                await self._close_all(price, pos["close_fail"],
                                      reanalyze=pos.get("close_reanalyze", True))
                return
            if pos.get("restop"):              # свежий вердикт → перенос троса
                await self._replace_stop(pos)
            sgn = 1.0 if pos["side"] == "long" else -1.0
            floating = (price - pos["entry"]) * sgn * pos["lots"] * self.point_value
            pos["floating"] = round(floating, 2)
            # маржевой дозор: капитал не тянет ГО → УЖАТЬСЯ до вмещающегося
            # (закрытие всего при −0.04% депозита убито — находка веера)
            per = self.per_lot(price, pos["side"])
            equity = self._free_cash() + floating
            need = (pos["lots"] + abs(self.foreign_lots)) * per
            if per > 0 and equity < need * MAINT_FRAC:
                fit = max(0, int(max(0.0, equity) * (1.0 - RESERVE_FRAC) // per)
                          - abs(self.foreign_lots))
                if fit <= 0:
                    await self._close_all(price, "маржевой дозор: капитал "
                                          f"{equity:.0f} не тянет ГО {need:.0f}")
                else:
                    await self._reduce(pos, pos["lots"] - fit, price,
                                       f"маржевой дозор: ужатие до {fit} лот")
                return
            # виртуальный дубль троса (реальный стоп лежит на бирже; _close_all
            # сам сверится с биржей, если трос уже исполнен — дубля не будет)
            inv = _f(pos.get("invalidation"))
            if inv > 0 and ((pos["side"] == "long" and price <= inv)
                            or (pos["side"] == "short" and price >= inv)):
                await self._close_all(price, f"аварийный стоп @{inv}")
                return
            # ПОБЕДА: тейк достигнут → продаём ВСЁ (на макс)
            take = _f(pos.get("take"))
            if take > 0 and ((pos["side"] == "long" and price >= take)
                             or (pos["side"] == "short" and price <= take)):
                await self._close_all(price, f"ПОБЕДА: тейк @{take} — всё в кассу")
                return
            # флип: свежий план в другую сторону → сначала закрыть
            if self.plan and self.plan["side"] != pos["side"]:
                await self._close_all(price, "флип по новому вердикту",
                                      reanalyze=False)
                return
            self.state = "В_ПОЗИЦИИ"
            self.last_action = (f"в позиции {pos['side']} {pos['lots']} лот "
                                f"@{pos['entry']:g}, плавающий {floating:+.0f}")

        # 3. засада: ждём имба-момент (только на живом рынке)
        elif self.plan and self.state != "ПЕРЕАНАЛИЗ" and not self._reanalyzing:
            if time.time() < self.no_entry_until:
                self.last_action = "бэкофф после отказов биржи — жду"
            elif not self._market_alive():
                self.state = "ЗАСАДА" if self.plan.get("entry") is not None \
                    else self.state
                self.last_action = ("рынок мёртв (стакан пуст/протух — ночь, "
                                    "аукцион?) — входов нет, жду живой стакан")
            elif self._at_limit(self.plan["side"], price):
                self.last_action = "цена у планки — вход в лок запрещён"
            elif time.time() - _f(self.plan.get("ts")) > PLAN_TTL_SEC:
                # ПРИКАЗ ПРОТУХ (пилот живёт весь день): утренняя засада к
                # обеду говорит о другом рынке — входим не по ней, а по
                # свежему разбору
                age_m = int((time.time() - _f(self.plan.get("ts"))) / 60)
                self.plan = None
                self.state = "ЖДУ_ПЛАН"
                self.last_action = (f"приказ протух ({age_m} мин, предел "
                                    f"{int(PLAN_TTL_SEC/60)}) — прошу свежий "
                                    f"разбор, по старой цене не захожу")
                log.info("ИИ-пилот %s: %s", self.base, self.last_action)
                self._fire_reanalyze("приказ протух")
            else:
                inv = _f(self.plan.get("invalidation"))
                dead = ((self.plan["side"] == "long" and price <= inv)
                        or (self.plan["side"] == "short" and price >= inv))
                if dead:
                    # цена уже ЗА стопом — вход в мёртвую идею запрещён
                    self.plan = None
                    self.state = "ЖДУ_ПЛАН"
                    self.last_action = (f"цена {price:g} уже за invalidation "
                                        f"{inv:g} — идея мертва ДО входа, "
                                        "прошу свежий разбор")
                    log.warning("ИИ-пилот %s: %s", self.base, self.last_action)
                    self._fire_reanalyze("идея мертва до входа")
                else:
                    lvl = self.plan.get("entry")
                    if lvl is None:
                        await self._enter(price, book)
                    else:
                        lvl = _f(lvl)
                        arm = (ARM_TICKS * self.tick_size if self.tick_size > 0
                               else price * ARM_FRAC)
                        near = ((price <= lvl + arm) if self.plan["side"] == "long"
                                else (price >= lvl - arm))
                        if near:
                            await self._enter(price, book)
                        else:
                            self.state = "ЗАСАДА"
                            self.last_action = (f"засада {self.plan['side']} "
                                                f"@{lvl:g} (цена {price:g}, "
                                                "жду имба-момент)")

        # 3б. отложенный пейсингом разбор: как только окно открылось —
        #     просим его сами (иначе пилот встал бы колом до перепроверки)
        if (self._reanalyze_pending and not self._reanalyzing
                and not self.position and not self.pending
                and time.time() - self._last_reanalyze_ts >= REANALYZE_GAP_SEC):
            self._fire_reanalyze(self._reanalyze_pending)

        # 4. сверка с биржей: всегда (не только при позиции — иначе слепые
        #    окна изоляции; находка веера) + свежие деньги/ГО
        if self._tick_n % RECONCILE_EVERY == 0:
            await self._reconcile(price)

        # 5. 30-минутная перепроверка — только на живом рынке и не во время
        #    переанализа (решение по замороженной цене — деньги на ветер)
        if (time.time() >= self.review_ts and not self._review_busy
                and self.state != "СТОП" and not self._reanalyzing):
            if not self._market_alive():
                self.review_ts = time.time() + 600     # рынок мёртв — отложили
                self.last_action = "перепроверка отложена: рынок мёртв"
            else:
                self.review_ts = time.time() + REVIEW_SEC
                asyncio.get_running_loop().create_task(self._review_bg(price))

    # ── вход: агрессивная лимитка в спред (рыночные входы запрещены) ────────
    def _aggr_price(self, side: str, price: float, book: dict | None) -> float:
        bb = _f((book or {}).get("best_bid"))
        ba = _f((book or {}).get("best_ask"))
        tick = self.tick_size if self.tick_size > 0 else max(price * 1e-5, 1e-6)
        if bb > 0 and ba > bb:
            if side == "long":
                px = min(bb + tick, ba - tick)
                px = px if px > bb else bb
            else:
                px = max(ba - tick, bb + tick)
                px = px if px < ba else ba
        else:
            px = price
        return self._snap(px)

    async def _enter(self, price: float, book: dict | None,
                     attempts: int = 0) -> None:
        if not self.plan:
            return
        side = self.plan["side"]
        lots = self.max_lots(price, side)
        if lots <= 0:
            self.last_action = ("депозит не тянет ни лота — входа нет "
                                "(честно, без пыли)")
            self.plan = None
            self.state = "ЖДУ_ПЛАН"
            log.warning("ИИ-пилот %s: %s", self.base, self.last_action)
            return
        px = self._aggr_price(side, price, book)
        r = await self.broker.place(self.figi, BUY if side == "long" else SELL,
                                    lots, price=px, tag="aip-entry")
        if not r.get("ok"):
            self._entry_fail += 1
            self.no_entry_until = time.time() + min(120.0, 2.0 * 2 ** self._entry_fail)
            self.last_action = (f"вход отбит ({r.get('note') or r.get('error')})"
                                f" — бэкофф, попытка {self._entry_fail}")
            if self._entry_fail >= ENTRY_FAIL_MAX:
                self.plan = None
                self.state = "ЖДУ_ПЛАН"
                self.last_action = ("биржа стабильно отбивает вход — план "
                                    "сброшен, прошу свежий разбор")
                self._fire_reanalyze("вход невозможен: серия отказов биржи")
            return
        # заявка несёт СВОИ уровни (снимок плана): новый план поверх летящей
        # заявки больше не приклеивает чужие тейк/стоп (находка веера)
        self.pending = {"order_id": r["order_id"], "side": side, "lots": lots,
                        "price": px, "ts": time.time(), "attempts": attempts,
                        "take": self.plan.get("take"),
                        "invalidation": self.plan.get("invalidation"),
                        "why": self.plan.get("why", "")}
        self.state = "ВХОЖУ"
        self.last_action = (f"бью агрессивной лимиткой: {side} {lots} лот @{px:g}"
                            + (f" (перевзвод №{attempts})" if attempts else ""))
        log.info("ИИ-пилот %s: %s", self.base, self.last_action)

    async def _order_part(self, po: dict) -> tuple[int, bool]:
        """(исполнено лотов, полностью?). Опрос судьбы заявки."""
        st = await self.broker.order_state(po["order_id"])
        if st.get("filled"):
            return int(po["lots"]), True
        try:
            part = max(0, min(int(po["lots"]), int(st.get("exec_lots") or 0)))
        except (TypeError, ValueError):
            part = 0
        return part, False

    async def _cancel_pending(self) -> tuple[int, dict | None]:
        """Снять заявку входа; вернуть (налитые лоты, снимок заявки).
        После cancel — ПОВТОРНЫЙ опрос: между снятием и опросом могли долить
        (гонка «частичка после cancel» — находка веера)."""
        po, self.pending = self.pending, None
        self._cancel_entry = False
        if not po:
            return 0, None
        part, full = await self._order_part(po)
        if full:
            return int(po["lots"]), po
        await self.broker.cancel(po["order_id"])
        part2, full2 = await self._order_part(po)
        if full2:
            return int(po["lots"]), po
        return max(part, part2), po

    async def _pending_tick(self, price: float, book: dict | None) -> None:
        po = self.pending
        # новый план/паника потребовали снять заявку — частичку в работу
        if self._cancel_entry:
            part, po2 = await self._cancel_pending()
            if part > 0 and po2:
                await self._absorb_fill(part, po2)
            return
        st = await self.broker.order_state(po["order_id"])
        s = str(st.get("status") or "")
        if st.get("filled"):
            self.pending = None
            await self._absorb_fill(po["lots"], po)
            return
        part = 0
        ex = st.get("exec_lots")
        if ex is not None:
            try:
                part = max(0, min(int(po["lots"]), int(ex)))
            except (TypeError, ValueError):
                part = 0
        if s.endswith("REJECTED") or s.endswith("CANCELLED"):
            self.pending = None
            if part > 0:
                await self._absorb_fill(part, po)
                return
            # отказ биржи: бэкофф и счётчик (штурм каждые 1.5с убит)
            self._entry_fail += 1
            self.no_entry_until = time.time() + min(120.0, 2.0 * 2 ** self._entry_fail)
            if self._entry_fail >= ENTRY_FAIL_MAX:
                self.plan = None
                self.state = "ЖДУ_ПЛАН"
                self.last_action = (f"биржа отбивает заявки ({s}) — план "
                                    "сброшен, прошу свежий разбор")
                self._fire_reanalyze("серия отказов биржи")
                return
            self.state = "ЗАСАДА" if (self.plan or {}).get("entry") is not None \
                else "ЖДУ_ПЛАН"
            self.last_action = f"заявку отбила биржа ({s}) — бэкофф и перевзвод"
            return
        ran = abs(price - po["price"]) / po["price"] if po["price"] else 0.0
        if time.time() - po["ts"] > ENTRY_TTL_SEC or ran > RUN_FRAC:
            self.pending = None
            await self.broker.cancel(po["order_id"])
            part2, full2 = await self._order_part(po)   # опрос ПОСЛЕ cancel
            if full2:
                await self._absorb_fill(po["lots"], po)
                return
            part = max(part, part2)
            if part > 0:                       # частичку берём в работу
                await self._absorb_fill(part, po)
                return
            att = po["attempts"] + 1
            if att <= MAX_REPRICINGS:
                await self._enter(price, book, attempts=att)
                return
            # финальная эскалация «мы точно заходим»: МАРКЕТ-ЭЙБЛ ЛИМИТ по
            # best противоположной стороны (лимитка, не рыночный)
            bb = _f((book or {}).get("best_bid"))
            ba = _f((book or {}).get("best_ask"))
            cross = ba if po["side"] == "long" else bb
            if cross > 0:
                lots = self.max_lots(price, po["side"])
                if lots > 0:
                    cross = self._snap(cross)
                    r = await self.broker.place(
                        self.figi, BUY if po["side"] == "long" else SELL,
                        lots, price=cross, tag="aip-cross")
                    if r.get("ok"):
                        self.pending = {"order_id": r["order_id"],
                                        "side": po["side"], "lots": lots,
                                        "price": cross, "ts": time.time(),
                                        "attempts": att,
                                        "take": po.get("take"),
                                        "invalidation": po.get("invalidation"),
                                        "why": po.get("why", "")}
                        self.last_action = (f"эскалация: лимит по best "
                                            f"{cross:g} — точно заходим")
                        return
            self.state = "ЗАСАДА" if (self.plan or {}).get("entry") is not None \
                else "ЖДУ_ПЛАН"
            self.last_action = ("ликвидности нет даже по best — отступил, "
                                "жду имба-момент заново")

    async def _absorb_fill(self, lots: int, po: dict,
                           place_stop: bool = True) -> None:
        """Исполненные лоты заявки → управляемая позиция. Уровни — ИЗ ЗАЯВКИ
        (снимок плана на момент выставления), не из текущего plan."""
        side, px = po["side"], po["price"]
        if self.position and self.position["side"] == side:
            p = self.position                  # доусреднение частичек
            tot = p["lots"] + int(lots)
            p["entry"] = (p["entry"] * p["lots"] + px * int(lots)) / tot
            p["lots"] = tot
            p["restop"] = True                 # трос → на суммарный объём
        else:
            self.position = {"side": side, "entry": float(px), "lots": int(lots),
                             "take": po.get("take"),
                             "invalidation": po.get("invalidation"),
                             "opened_ts": time.time(), "stop_id": None,
                             "floating": 0.0}
        # план потреблён, ТОЛЬКО если это его сторона (частичка старой заявки
        # при новом противоположном плане не должна съесть новый план)
        if self.plan and self.plan["side"] == side:
            self.plan = None
        self._entry_fail = 0
        if not self.position:
            return
        pos = self.position
        if place_stop:
            await self._replace_stop(pos)
        if not self.plan:
            self.state = "В_ПОЗИЦИИ"
        self.review_ts = time.time() + REVIEW_SEC
        self._save_state()
        troos = (f"трос @{pos.get('invalidation')}" if pos.get("stop_id")
                 else "⚠ ТРОС НЕ ВСТАЛ — держу виртуальный стоп")
        self.last_action = (f"ВОШЁЛ: {side} {pos['lots']} лот @{pos['entry']:g}, "
                            f"{troos}, тейк {pos.get('take')}")
        log.info("ИИ-пилот %s: %s", self.base, self.last_action)

    async def _replace_stop(self, pos: dict) -> None:
        """Биржевой трос: перевыставить на актуальные объём/уровень.
        Отказ не глотается: stop_id=None и честное предупреждение."""
        pos.pop("restop", None)
        if pos.get("stop_id"):
            await self.broker.cancel_stop(pos["stop_id"])
            pos["stop_id"] = None
        inv = _f(pos.get("invalidation"))
        if inv <= 0:
            return
        rs = await self.broker.place_stop(
            self.figi, SELL if pos["side"] == "long" else BUY,
            pos["lots"], self._snap(inv), tag="aip-tros")
        if rs.get("ok"):
            pos["stop_id"] = rs.get("stop_order_id")
        else:
            pos["stop_id"] = None
            log.warning("ИИ-пилот %s: ⚠ биржевой трос НЕ встал (%s) — только "
                        "виртуальный стоп", self.base,
                        str(rs.get("error") or rs.get("note"))[:100])
        self._save_state()

    # ── реальный остаток своих лотов на бирже (для аккуратного закрытия) ────
    async def _real_own_lots(self, pos: dict) -> int | None:
        """Сколько НАШИХ лотов реально осталось на счёте (None = не узнали)."""
        pf = await self.broker.portfolio()
        if pf.get("error") is not None:
            return None
        if pf.get("mode") == "dry":
            return pos["lots"]                 # dry: биржи нет, верим учёту
        real = 0
        for p_ in pf.get("positions") or []:
            if p_.get("figi") == self.figi:
                q = _f(p_.get("qty"))
                real = (int(q) if self.asset_class == "futures"
                        else int(q / max(1.0, self.point_value)))
                break
        sgn = 1 if pos["side"] == "long" else -1
        own_dir = (real - self.foreign_lots) * sgn
        return max(0, min(pos["lots"], own_dir))

    # ── закрытие всего (победа/стоп/решение ИИ) ─────────────────────────────
    async def _close_all(self, price: float, why: str,
                         reanalyze: bool = True) -> bool:
        pos = self.position
        if not pos:
            return True
        lots = int(pos["lots"])
        est_px = price if price and price > 0 else _f(pos.get("entry"))
        # 1) снять трос; НЕ снялся в real → возможно уже исполнен на бирже:
        #    сверяемся и закрываем ТОЛЬКО фактический остаток (двойное
        #    закрытие с голым разворотом убито — находка веера)
        if pos.get("stop_id"):
            rc = await self.broker.cancel_stop(pos["stop_id"])
            pos["stop_id"] = None
            if not rc.get("ok"):
                real = await self._real_own_lots(pos)
                if real is None:
                    pos["close_fail"] = why    # биржа молчит — повтор тиком
                    pos["close_reanalyze"] = reanalyze
                    self.last_action = ("трос не снялся и биржа молчит — "
                                        "закрытие повторю тиком")
                    return False
                if real < lots:
                    log.warning("ИИ-пилот %s: трос уже исполнился на бирже "
                                "(%d из %d лот) — закрываю остаток %d",
                                self.base, lots - real, lots, real)
                    est_px = _f(pos.get("invalidation")) or est_px
                lots = real
        # 2) рыночное закрытие остатка (выход рыночным разрешён — это не вход)
        if lots > 0:
            d = SELL if pos["side"] == "long" else BUY
            r = await self.broker.place(self.figi, d, lots, price=None,
                                        tag="aip-close")
            if not r.get("ok"):
                # биржа отбила (планка/клиринг/сеть): позиция ОСТАЁТСЯ в
                # учёте, закрытие повторяется каждый тик (не «исчезла с
                # бумаги, но жива на счёте» — находка веера)
                pos["close_fail"] = why
                pos["close_reanalyze"] = reanalyze
                self.last_action = (f"закрытие отбито биржей "
                                    f"({str(r.get('error') or r.get('note'))[:80]})"
                                    " — повторяю каждый тик")
                log.warning("ИИ-пилот %s: %s", self.base, self.last_action)
                return False
        # 3) учёт (честно: P/L по последней цене тика, не по факту исполнения)
        sgn = 1.0 if pos["side"] == "long" else -1.0
        pnl = (est_px - pos["entry"]) * sgn * pos["lots"] * self.point_value
        self.pnls.append(pnl)
        if self.session_risk:
            self.session_risk.record(pnl)
        self.position = None
        self._save_state()
        self.state = "ЖДУ_ПЛАН"
        self.last_action = f"ЗАКРЫЛ ВСЁ ({why}): P/L {pnl:+.0f}"
        log.info("ИИ-пилот %s: %s", self.base, self.last_action)
        if reanalyze and not (self.session_risk and self.session_risk.locked):
            self._fire_reanalyze("после закрытия — огромный анализ с нуля")
        return True

    async def _reduce(self, pos: dict, excess: int, price: float,
                      why: str) -> None:
        """Частичное ужатие позиции (дозор): закрыть excess лотов, трос — на
        остаток. P/L срезанной части — в killswitch."""
        excess = max(0, min(int(excess), pos["lots"]))
        if excess <= 0:
            return
        d = SELL if pos["side"] == "long" else BUY
        r = await self.broker.place(self.figi, d, excess, price=None,
                                    tag="aip-reduce")
        if not r.get("ok"):
            self.last_action = f"ужатие отбито биржей — повторю тиком ({why})"
            return
        sgn = 1.0 if pos["side"] == "long" else -1.0
        pnl = (price - pos["entry"]) * sgn * excess * self.point_value
        self.pnls.append(pnl)
        if self.session_risk:
            self.session_risk.record(pnl)
        pos["lots"] -= excess
        pos["restop"] = True
        self._save_state()
        self.last_action = f"{why}: срезал {excess} лот (P/L {pnl:+.0f})"
        log.warning("ИИ-пилот %s: %s", self.base, self.last_action)

    # ── сверка с биржей: изоляция, внешние закрытия, свежие деньги/ГО ───────
    async def _reconcile(self, price: float) -> None:
        pf = await self.broker.portfolio()
        if pf.get("mode") == "dry" or pf.get("error"):
            return
        cash = pf.get("cash")
        if cash is not None:
            self._live_cash = _f(cash)         # свежие деньги (вармаржа и пр.)
        if self.asset_class == "futures" and self._tick_n % (RECONCILE_EVERY * 5) == 0:
            try:                               # ГО биржа меняет — обновляем
                mg = await tinkoff.futures_margin(self.figi) or {}
                if _f(mg.get("margin_buy")) > 0:
                    self.go_per_lot = mg.get("margin_buy")
                    self.go_sell = mg.get("margin_sell")
            except Exception:                                # noqa: BLE001
                pass
        real = 0
        for p_ in pf.get("positions") or []:
            if p_.get("figi") == self.figi:
                qty = _f(p_.get("qty"))
                real = (int(qty) if self.asset_class == "futures"
                        else int(qty / max(1.0, self.point_value)))
                break
        own = 0
        if self.position:
            own = (self.position["lots"] if self.position["side"] == "long"
                   else -self.position["lots"])
        if real == own + self.foreign_lots:
            return
        if own == 0 and self.foreign_lots == 0 and real != 0:
            if not self._stray_warned:
                self._stray_warned = True
                log.warning("ИИ-пилот %s: на счёте %+d лот, которых пилот не "
                            "знает — считаю ручными владельца, НЕ трогаю "
                            "(изоляция)", self.base, real)
            self.foreign_lots = real
            return
        sgn = 1 if own > 0 else (-1 if own < 0 else 0)
        new_own = min(abs(own), max(0, real * sgn)) * sgn if sgn else 0
        self.foreign_lots = real - new_own
        if own and not new_own:
            # позицию закрыло что-то вне петли: биржевой трос или владелец.
            # Стоп-сироту снять ОБЯЗАТЕЛЬНО (иначе позже откроет позицию)
            pos, self.position = self.position, None
            if pos.get("stop_id"):
                await self.broker.cancel_stop(pos["stop_id"])
            sgn_f = 1.0 if pos["side"] == "long" else -1.0
            est = _f(pos.get("invalidation")) or price
            pnl = (est - pos["entry"]) * sgn_f * pos["lots"] * self.point_value
            self.pnls.append(pnl)
            if self.session_risk:
                self.session_risk.record(pnl)
            self._save_state()
            self.state = "ЖДУ_ПЛАН"
            self.last_action = (f"позицию закрыла биржа/владелец (трос?): "
                                f"P/L ≈{pnl:+.0f} по уровню стопа/цене")
            log.warning("ИИ-пилот %s: %s", self.base, self.last_action)
            if not (self.session_risk and self.session_risk.locked):
                self._fire_reanalyze("внешнее закрытие — свежий разбор")
        elif new_own != own and self.position:
            cut = abs(own) - abs(new_own)
            sgn_f = 1.0 if self.position["side"] == "long" else -1.0
            pnl = (price - self.position["entry"]) * sgn_f * cut * self.point_value
            self.pnls.append(pnl)              # срез виден killswitch'у
            if self.session_risk:
                self.session_risk.record(pnl)
            self.position["lots"] = abs(new_own)
            self.position["restop"] = True     # трос — на новый объём
            self._save_state()
            self.last_action = (f"сверка: моих лотов теперь {abs(new_own)} "
                                f"(срез {cut}, P/L ≈{pnl:+.0f})")

    # ── 30-минутная перепроверка ────────────────────────────────────────────
    async def _gather_news(self) -> str:
        try:
            from . import news as news_mod
        except ImportError:
            import news as news_mod
        blocks = []
        try:
            items, note = await asyncio.wait_for(
                news_mod.fetch_for_ticker(self.base, self.name,
                                          asset_class=self.asset_class),
                timeout=30)
            if items:
                blocks.append(f"— по компании ({note}):\n"
                              + news_mod.render_for_ai(items, limit=15))
        except Exception as e:                               # noqa: BLE001
            log.info("новости компании молчат: %s", str(e)[:60])
        try:
            common = await asyncio.wait_for(news_mod.fetch_news(days=1),
                                            timeout=30)
            if common:
                blocks.append("— общий поток (сутки):\n"
                              + news_mod.render_for_ai(common, limit=25))
        except Exception as e:                               # noqa: BLE001
            log.info("общий поток молчит: %s", str(e)[:60])
        return "\n\n".join(blocks)

    async def _last_verdict(self) -> str:
        try:
            try:
                from . import memory
            except ImportError:
                import memory
            rec = await memory.get_analysis(self.base)
            return (rec or {}).get("verdict") or ""
        except Exception:                                    # noqa: BLE001
            return ""

    def _situation_text(self, price: float) -> str:
        L = [f"Цена сейчас: {price:g}"]
        if len(self.prices) > 2:
            n30 = int(1800 / TICK_SEC)
            base = self.prices[-n30] if len(self.prices) >= n30 else self.prices[0]
            if base > 0:
                L.append(f"Ход за окно наблюдения: {(price/base-1)*100:+.2f}%")
        b = self.last_book or {}
        if b.get("best_bid") and b.get("best_ask"):
            L.append(f"Стакан: bid {b['best_bid']} / ask {b['best_ask']}"
                     + (f", дисбаланс {b.get('imbalance')}"
                        if b.get("imbalance") is not None else ""))
        if self.position:
            p = self.position
            held = int((time.time() - p["opened_ts"]) / 60)
            L.append(f"ПОЗИЦИЯ: {p['side']} {p['lots']} лот @{p['entry']:g}, "
                     f"в рынке {held} мин, плавающий P/L {p.get('floating', 0):+.0f} ₽, "
                     f"трос @{p.get('invalidation')}, тейк {p.get('take')}")
        elif self.pending:
            L.append(f"ЗАЯВКА ВХОДА В ПОЛЁТЕ: {self.pending['side']} "
                     f"{self.pending['lots']} лот @{self.pending['price']}")
        elif self.plan:
            L.append(f"ЗАСАДА: {self.plan['side']} @{self.plan.get('entry')} "
                     f"(жду имба-момент), стоп {self.plan['invalidation']}")
        else:
            L.append("Позиции нет, засады нет — полностью вне рынка")
        L.append(f"Депозит {self.deposit:.0f} ₽, результат сессии "
                 f"{sum(self.pnls):+.0f} ₽ за {len(self.pnls)} сделок")
        if self.last_review:
            age = int((time.time() - self.last_review["ts"]) / 60)
            L.append(f"Прошлая перепроверка ({age} мин назад): "
                     f"{self.last_review['choice']} — {self.last_review['why']}")
        sr = self.session_risk.state() if self.session_risk else {}
        if sr:
            L.append(f"Killswitch: {'ЗАБЛОКИРОВАН' if sr.get('locked') else 'ок'}"
                     f" (дневной лимит {sr.get('day_loss_limit')})")
        return "\n".join(L)

    async def _review_bg(self, price: float) -> None:
        self._review_busy = True
        try:
            await self._review(price)
        except Exception as e:                               # noqa: BLE001
            log.warning("перепроверка споткнулась: %s", str(e)[:120])
        finally:
            self._review_busy = False

    @staticmethod
    def _parse_choice(raw: str, in_pos: bool) -> str:
        """Нестрогий разбор решения: «ЗАКРЫТЬ ВСЁ», «КУПИТЬ СЕЙЧАС!», ё/е,
        регистр — всё это валидные решения, а не молчаливый ЖДЁМ."""
        c = (raw or "").upper().replace("Ё", "Е")
        if "АНАЛИЗ" in c or "НОВЫЙ" in c or "НОВЫИ" in c:
            return "НОВЫЙ_АНАЛИЗ"
        if in_pos and ("ЗАКР" in c or "ПРОДА" in c or "ВЫЙТИ" in c or "ВЫХОД" in c):
            return "ЗАКРЫТЬ"
        if not in_pos and "КУП" in c:
            return "КУПИТЬ_СЕЙЧАС"
        if not in_pos and ("ПРОДА" in c or "ШОРТ" in c):
            return "ПРОДАТЬ_СЕЙЧАС"
        return "ЖДЁМ"

    async def _review(self, price: float) -> None:
        try:
            from . import prompts
        except ImportError:
            import prompts
        ask_json = self._ai_ask_json
        if ask_json is None:
            try:
                from . import ai as ai_mod
            except ImportError:
                import ai as ai_mod
            ask_json = ai_mod.ask_json
        in_pos = self.position is not None
        news_txt, verdict = await asyncio.gather(self._gather_news(),
                                                 self._last_verdict())
        if not news_txt.strip():
            news_txt = ("(новости недоступны: сбой сбора — НЕ выдумывай их, "
                        "решай по цене, стакану и вердикту)")
        obj = await asyncio.wait_for(ask_json(
            prompts.REVIEW_SYS,
            prompts.review_user(self.base, self.name,
                                self._situation_text(price), verdict,
                                news_txt, in_pos),
            route="aip_review"), timeout=300)
        if not isinstance(obj, dict):
            log.warning("перепроверка: ИИ не дал JSON — держу как есть")
            return
        choice = self._parse_choice(str(obj.get("choice") or ""), in_pos)
        why = str(obj.get("why") or "")[:300]
        self.last_review = {"choice": choice, "why": why, "ts": time.time()}
        log.info("ИИ-пилот %s: перепроверка → %s (%s)", self.base, choice, why)
        cur = self.prices[-1] if self.prices else price
        # решение по протухшему снимку не исполняется: цена ушла >1% от
        # снимка, по которому думал ИИ → честный свежий разбор (находка веера)
        drift = abs(cur - price) / price if price else 0.0
        if choice in ("КУПИТЬ_СЕЙЧАС", "ПРОДАТЬ_СЕЙЧАС") and drift > DRIFT_FRAC:
            log.warning("перепроверка протухла: цена ушла %.2f%% за время "
                        "раздумий — вместо входа прошу свежий разбор",
                        drift * 100)
            self._fire_reanalyze("решение перепроверки протухло")
            return
        if choice == "ЗАКРЫТЬ" and self.position:
            await self._close_all(cur, "решение перепроверки: закрыть")
        elif choice in ("КУПИТЬ_СЕЙЧАС", "ПРОДАТЬ_СЕЙЧАС") and not self.position \
                and not self._reanalyzing:
            side = "long" if choice == "КУПИТЬ_СЕЙЧАС" else "short"
            inv = obj.get("invalidation")
            inv = _f(inv) if inv is not None else 0.0
            # стоп не с той стороны/нулевой → аварийная политика режима
            good = (inv > 0 and ((side == "long" and inv < cur)
                                 or (side == "short" and inv > cur)))
            if not good:
                inv = cur * (1 - EMERGENCY_STOP_FRAC if side == "long"
                             else 1 + EMERGENCY_STOP_FRAC)
                log.warning("перепроверка без валидного invalidation — "
                            "аварийный стоп %.6g (политика %.1f%%)", inv,
                            EMERGENCY_STOP_FRAC * 100)
            take = obj.get("take")
            take = _f(take) if take is not None else None
            if take is not None and not ((side == "long" and take > cur)
                                         or (side == "short" and take < cur)):
                log.warning("тейк %s не с той стороны от цены %s — снят", take, cur)
                take = None
            self.plan = {"side": side, "entry": None, "take": take,
                         "invalidation": round(inv, 6),
                         "why": "перепроверка: " + why, "ts": time.time()}
            if self.pending:                   # старая заявка — снять тиком
                self._cancel_entry = True
            self.state = "ВХОЖУ"
        elif choice == "НОВЫЙ_АНАЛИЗ":
            self._fire_reanalyze("перепроверка потребовала свежий разбор")
        # ЖДЁМ — осознанное решение: держим как есть

    # ── огромный анализ с нуля (сервер вешает колбэк) ───────────────────────
    def _fire_reanalyze(self, why: str) -> None:
        if self._reanalyzing:
            return
        if not self.reanalyze_cb:
            log.warning("ИИ-пилот %s: %s — но конвейер не подключён "
                        "(reanalyze_cb не задан)", self.base, why)
            return
        # ПЕЙСИНГ ДНЕВНОЙ РАБОТЫ: огромный анализ — пять стадий ИИ, это дорого
        # и долго. Пилот работает ВЕСЬ ДЕНЬ, поэтому просить новый разбор чаще
        # REANALYZE_GAP_SEC нельзя: иначе серия неудач (биржа отбивает, приказ
        # не собрался) сожгла бы ключ за час. Не отменяем — ОТКЛАДЫВАЕМ.
        wait = REANALYZE_GAP_SEC - (time.time() - self._last_reanalyze_ts)
        if self._last_reanalyze_ts and wait > 0:
            self._reanalyze_pending = why
            self.last_action = (f"{why} — новый разбор через {int(wait)}с "
                                f"(пейсинг: не чаще раза в "
                                f"{int(REANALYZE_GAP_SEC/60)} мин)")
            return
        self._reanalyze_pending = None
        self._last_reanalyze_ts = time.time()
        self.analyses += 1
        self._reanalyzing = True
        if not self.position:
            self.plan = None
            self.state = "ПЕРЕАНАЛИЗ"
        log.info("ИИ-пилот %s: %s — запускаю конвейер", self.base, why)

        async def _run():
            try:
                await self.reanalyze_cb()
            except Exception as e:                           # noqa: BLE001
                log.warning("переанализ упал: %s", str(e)[:120])
            finally:
                if self._reanalyzing:          # колбэк не донёс adopt_forecast
                    self._reanalyzing = False
                    if self.state == "ПЕРЕАНАЛИЗ":
                        self.state = "ЖДУ_ПЛАН"
                        # без свежего приказа — ранняя перепроверка решит сама
                        self.review_ts = min(self.review_ts, time.time() + 300)

        asyncio.get_running_loop().create_task(_run())

    # ── статус/управление ───────────────────────────────────────────────────
    def status(self) -> dict:
        sr = self.session_risk.state() if self.session_risk else {}
        return {"base": self.base, "mode": getattr(self.broker, "mode", "dry"),
                "pilot": "ИИ-ПИЛОТ", "state": self.state,
                "plan": self.plan, "position": self.position,
                "pending": bool(self.pending),
                "deposit": self.deposit, "go_per_lot": self.go_per_lot,
                "session_pnl": round(sum(self.pnls), 2),
                "trades": len(self.pnls),
                # смена: пилот держится весь день — видно, сколько отработал
                "uptime_h": round((time.time() - self.started_ts) / 3600.0, 1),
                "analyses": self.analyses,
                "foreign_lots": self.foreign_lots or None,
                "last_action": self.last_action,
                "last_review": self.last_review,
                "next_review_in_s": max(0, int(self.review_ts - time.time())),
                "market_alive": self._market_alive(),
                "killswitch": sr, "frame": FRAME}

    def panic(self) -> None:
        self.panic_flag = True

    def stop(self) -> None:
        self.stopping = True

    async def run(self) -> None:
        ok = await self.prepare()
        if not ok:
            return
        while not self.stopping:
            try:
                lp = await tinkoff.last_price(self.figi)
                px = _f((lp or {}).get("price"))
                book = None
                try:
                    book = await tinkoff.orderbook(self.figi, depth=10)
                except Exception:                            # noqa: BLE001
                    pass
                # ПАНИКА/killswitch обязаны исполняться и БЕЗ свежей цены
                if px <= 0 and (self.panic_flag or
                                (self.session_risk and self.session_risk.locked)):
                    px = (self.prices[-1] if self.prices
                          else _f((self.position or {}).get("entry")))
                if px > 0:
                    await self.tick(px, book)
            except Exception as e:                           # noqa: BLE001
                log.warning("тик ИИ-пилота споткнулся: %s", str(e)[:120])
            await asyncio.sleep(TICK_SEC)
        # аккуратный выход: заявку снять (частичка — в учёт), позицию НЕ
        # закрываем сами (решение владельца), трос остаётся на бирже
        part, po = await self._cancel_pending()
        if part > 0 and po:
            await self._absorb_fill(part, po)
        if self.position:
            log.warning("ИИ-пилот %s остановлен: позиция %s %d лот ОСТАЁТСЯ "
                        "под биржевым тросом — веди сам или включи пилот",
                        self.base, self.position["side"], self.position["lots"])


# ══════════════════════════════════════════════════════════════════════════
# Self-тест: вся машина без сети (фейковый брокер + фейковый ИИ)
# ══════════════════════════════════════════════════════════════════════════
if __name__ == "__main__":

    class FakeBroker:
        """Мини-биржа: заявки, судьба, стопы, портфель. Ничего в сеть."""
        mode = "real"

        def __init__(self):
            self.placed, self.stops, self.cancelled = [], [], []
            self.stop_cancels = []
            self.fill_next = True            # place → сразу FILL?
            self.place_ok = True             # биржа принимает заявки?
            self.cancel_stop_ok = True       # трос снимается?
            self.partial: dict = {}          # order_id → exec_lots
            self.pf_positions = []           # портфель для сверок
            self.pf_cash = None
            self._n = 0

        async def place(self, figi, direction, lots, price=None, tag=""):
            if not self.place_ok:
                return {"ok": False, "error": "биржа закрыта (тест)"}
            self._n += 1
            oid = f"F-{self._n}"
            self.placed.append({"order_id": oid, "figi": figi,
                                "direction": direction, "lots": lots,
                                "price": price, "tag": tag})
            return {"ok": True, "order_id": oid}

        async def order_state(self, oid):
            if oid in self.partial:
                return {"ok": True, "filled": False, "status": "PARTIAL",
                        "exec_lots": self.partial[oid]}
            return {"ok": True, "filled": self.fill_next, "status": "FILL"}

        async def cancel(self, oid):
            self.cancelled.append(oid)
            return {"ok": True}

        async def place_stop(self, figi, direction, lots, stop_price, tag=""):
            self.stops.append({"figi": figi, "direction": direction,
                               "lots": lots, "stop": stop_price})
            return {"ok": True, "stop_order_id": f"S-{len(self.stops)}"}

        async def cancel_stop(self, sid):
            self.stop_cancels.append(sid)
            if not self.cancel_stop_ok:
                return {"ok": False, "error": "stop already executed"}
            return {"ok": True}

        async def portfolio(self):
            return {"mode": "real", "cash": self.pf_cash,
                    "positions": self.pf_positions}

    def mk(dep=100000.0, go=12000.0, tick=1.0, go_sell=None):
        """Реалистичный фьючерс: ГО ≈ 13% номинала 90000 (плечо ~7.5)."""
        p = AIPilot("TEST", deposit=dep, broker=FakeBroker())
        p.figi, p.asset_class = "FIGI-T", "futures"
        p.go_per_lot, p.go_sell = go, go_sell
        p.tick_size, p.point_value = tick, 1.0
        p.deposit = dep
        p.session_risk = trader_risk.SessionRisk(dep)
        p._sr_day = p._msk_day()
        p._state_path = None                 # тестам файл не нужен
        return p

    BOOK = {"best_bid": 89999.0, "best_ask": 90001.0}

    def ex(do="BUY", entry=None, take=None, inv=None, why="т"):
        return {"exec": {"do": do, "entry": entry, "take": take,
                         "invalidation": inv, "why": why}}

    async def main():
        # 1) приказ принимается; без exec / с мусорными сторонами — отказ
        p = mk()
        assert p.adopt_forecast(ex("BUY", entry=89500.0, take=91000.0,
                                   inv=89000.0)) and p.state == "ЗАСАДА"
        p1 = mk()
        assert p1.adopt_forecast({"action": "LONG"}) is False
        assert p1.adopt_forecast(ex("BUY", entry=90000, inv=91000)) is False, \
            "BUY со стопом ВЫШЕ входа обязан быть отвергнут"
        assert p1.adopt_forecast(ex("SELL", entry=90000, inv=89000)) is False, \
            "SELL со стопом НИЖЕ входа обязан быть отвергнут"
        assert p1.adopt_forecast(ex("BUY", entry=90000, inv=-5)) is False
        assert p1.adopt_forecast(ex("BUY", entry=90000, take=89000,
                                    inv=88000)) is False   # тейк ниже входа

        # 2) максимум: фьючерс int(98000//12000)=8; шорт — по ГО продажи;
        #    изоляция режет ГО ручных лотов
        assert p.max_lots(90000.0, "long") == 8
        p2 = mk(go=12000.0, go_sell=14000.0)
        assert p2.max_lots(90000.0, "short") == 7           # 98000//14000
        p.foreign_lots = 2
        assert p.max_lots(90000.0, "long") == 6
        p.foreign_lots = 0

        # 2а) акция: плечо по dlong/dshort; нет ставок → на свои
        s = mk()
        s.asset_class, s.go_per_lot, s.point_value = "share", None, 10.0
        s.dlong, s.dshort = 0.25, 0.5
        assert s.max_lots(100.0, "long") == 392   # 98000//(100·10·0.25)
        assert s.max_lots(100.0, "short") == 196
        s.dlong = 0.0                              # не маржинальная
        assert s.max_lots(100.0, "long") == 98    # честно на свои

        # 3) рыночный гейт: мёртвый стакан → входа нет; живой → засада бьёт
        await p.tick(90020.0, None)               # стакана не было вовсе
        assert p.pending is None and "мёртв" in p.last_action
        await p.tick(95000.0, BOOK)               # далеко от засады
        assert p.pending is None and p.state == "ЗАСАДА"
        await p.tick(89504.0, BOOK)               # 89504 ≤ 89500+5·1 → бьём
        assert p.pending is not None
        e = p.broker.placed[-1]
        assert e["price"] is not None and BOOK["best_bid"] <= e["price"] <= BOOK["best_ask"]
        assert e["lots"] == 8 and e["direction"] == BUY
        assert p.pending["take"] == 91000.0       # заявка несёт СВОИ уровни

        # 4) исполнение → позиция, трос на бирже (снап к шагу), план потреблён
        await p.tick(89600.0, BOOK)
        assert p.position and p.position["lots"] == 8 and p.plan is None
        assert p.broker.stops[-1] == {"figi": "FIGI-T", "direction": SELL,
                                      "lots": 8, "stop": 89000.0}

        # 5) ПОБЕДА: тейк → закрыто всё рыночным, P/L учтён, реанализ пошёл
        fired = []

        async def cb():
            fired.append(1)

        p.reanalyze_cb = cb
        entry_px = p.position["entry"]
        await p.tick(91005.0, BOOK)
        assert p.position is None
        close = p.broker.placed[-1]
        assert close["price"] is None and close["direction"] == SELL and close["lots"] == 8
        assert abs(p.pnls[-1] - (91005.0 - entry_px) * 8) < 1e-6
        await asyncio.sleep(0)
        assert fired, "после победы обязан стартовать свежий разбор"

        # 6) МАРЖЕВОЙ ДОЗОР (находка веера): позиция на макс НЕ гибнет от
        #    шума; глубокая просадка → ЧАСТИЧНОЕ ужатие, трос на остаток
        p5 = mk()
        p5.adopt_forecast(ex("BUY", inv=1.0))     # стоп далеко: тестируем дозор
        await p5.tick(90000.0, BOOK)
        await p5.tick(90000.0, BOOK)
        assert p5.position and p5.position["lots"] == 8
        ep = p5.position["entry"]                 # 90000 (внутрь спреда)
        # мелкий минус (−0.1% цены) дозор НЕ трогает (раньше убивал бы всё)
        await p5.tick(ep - 90.0, BOOK)
        assert p5.position and p5.position["lots"] == 8, \
            "дозор не должен стрелять на шуме — находка веера"
        # глубже: equity=100000+(88000−ep)·8=84000 < 0.9·96000=86400 → ужатие
        await p5.tick(88000.0, BOOK)
        assert p5.position and p5.position["lots"] == 6, p5.position
        red = [x for x in p5.broker.placed if x["tag"] == "aip-reduce"]
        assert red and red[-1]["lots"] == 2 and red[-1]["price"] is None
        await p5.tick(88000.0, BOOK)              # restop отработал
        assert p5.broker.stops[-1]["lots"] == 6

        # 7) ДВОЙНОЕ ЗАКРЫТИЕ УБИТО: трос не снялся (уже исполнен на бирже),
        #    портфель пуст → рыночный НЕ шлётся, голого шорта нет
        p6 = mk()
        p6.adopt_forecast(ex("BUY", take=95000.0, inv=89000.0))
        await p6.tick(90000.0, BOOK)
        await p6.tick(90000.0, BOOK)
        assert p6.position and p6.position.get("stop_id")
        p6.broker.cancel_stop_ok = False          # стоп уже исполнился
        p6.broker.pf_positions = [{"figi": "FIGI-T", "qty": 0}]   # биржа пуста
        n_orders = len(p6.broker.placed)
        await p6.tick(88900.0, BOOK)              # цена за стопом → закрытие
        assert p6.position is None
        assert len(p6.broker.placed) == n_orders, \
            "рыночный ордер НЕ должен уходить: биржевой трос уже всё закрыл"
        assert abs(p6.pnls[-1] - (89000.0 - p6.broker.stops[-1]["stop"]
                                  * 0 - (90000.0)) * 8) < 1e9  # pnl по стопу:
        assert abs(p6.pnls[-1] - (89000.0 - 90000.0) * 8) < 1e-6

        # 8) отказ биржи на закрытии: позиция НЕ исчезает из учёта, добивается
        p7 = mk()
        p7.adopt_forecast(ex("BUY", take=91000.0, inv=89000.0))
        await p7.tick(90000.0, BOOK)
        await p7.tick(90000.0, BOOK)
        p7.broker.place_ok = False                # биржа отбивает всё
        await p7.tick(91500.0, BOOK)              # тейк, но закрыть нельзя
        assert p7.position is not None and p7.position.get("close_fail")
        p7.broker.place_ok = True
        await p7.tick(91500.0, BOOK)              # добили
        assert p7.position is None and p7.pnls

        # 9) ПАНИКА при частично налитой заявке: частичка закрывается, не
        #    теряется (находка веера)
        p8 = mk()
        p8.broker.fill_next = False
        p8.adopt_forecast(ex("BUY", inv=89000.0))
        await p8.tick(90000.0, BOOK)
        oid = p8.pending["order_id"]
        p8.broker.partial[oid] = 3                # налили 3 из 8
        p8.panic()
        await p8.tick(90000.0, BOOK)
        assert p8.state == "СТОП" and p8.position is None
        closes = [x for x in p8.broker.placed if x["tag"] == "aip-close"]
        assert closes and closes[-1]["lots"] == 3 and closes[-1]["direction"] == SELL, \
            "частичка обязана быть закрыта, а не потеряна"

        # 10) новый план поверх летящей заявки: заявка снимается, частичка
        #     живёт со СТАРЫМИ уровнями, потом флип по новому плану
        p9 = mk()
        p9.broker.fill_next = False
        p9.adopt_forecast(ex("BUY", take=91000.0, inv=89000.0))
        await p9.tick(90000.0, BOOK)
        p9.broker.partial[p9.pending["order_id"]] = 5
        assert p9.adopt_forecast(ex("SELL", take=88000.0, inv=91000.0))
        assert p9._cancel_entry
        await p9.tick(90000.0, BOOK)              # снятие + частичка в позицию
        assert p9.position and p9.position["side"] == "long" \
            and p9.position["lots"] == 5
        assert p9.position["take"] == 91000.0, "уровни — из СНИМКА заявки"
        assert p9.plan and p9.plan["side"] == "short", "новый план жив"
        p9.broker.fill_next = True
        await p9.tick(90000.0, BOOK)              # флип: закрыли лонг
        assert p9.position is None and "флип" in p9.last_action
        await p9.tick(90000.0, BOOK)              # вошли в шорт
        await p9.tick(90000.0, BOOK)
        assert p9.position and p9.position["side"] == "short"

        # 11) вход в мёртвую идею запрещён: цена уже за invalidation
        pa = mk()
        fired2 = []

        async def cb2():
            fired2.append(1)

        pa.reanalyze_cb = cb2
        pa.adopt_forecast(ex("BUY", entry=89500.0, inv=89000.0))
        await pa.tick(88500.0, BOOK)              # цена ниже стопа
        assert pa.pending is None and pa.plan is None
        await asyncio.sleep(0)
        assert fired2, "мёртвая идея → свежий разбор"

        # 12) REJECTED-штурм убит: бэкофф, после серии — план сброшен
        pb = mk()
        pb.adopt_forecast(ex("BUY", inv=89000.0))
        pb.broker.place_ok = False
        for _ in range(ENTRY_FAIL_MAX):
            pb.no_entry_until = 0.0               # тест: бэкофф скручен
            await pb.tick(90000.0, BOOK)
        assert pb.plan is None and "сброшен" in pb.last_action

        # 13) эскалация «точно заходим»: лимит по best ask, рыночных входов нет
        pc = mk()
        pc.broker.fill_next = False
        pc.adopt_forecast(ex("BUY", inv=89000.0))
        await pc.tick(90000.0, BOOK)
        for _ in range(MAX_REPRICINGS + 1):
            assert pc.pending
            pc.pending["ts"] -= (ENTRY_TTL_SEC + 1)
            await pc.tick(90000.0, BOOK)
        last = pc.broker.placed[-1]
        assert last["price"] == BOOK["best_ask"]
        entries = [x for x in pc.broker.placed if x["tag"] in ("aip-entry", "aip-cross")]
        assert all(x["price"] is not None for x in entries), \
            "рыночных ВХОДОВ быть не должно (закон «Абсолюта»)"

        # 14) перепроверка: нестрогий разбор решений + аварийный стоп при
        #     кривом invalidation + дрейф цены отменяет вход
        pd = mk()
        pd.adopt_forecast(ex("SELL", take=88000.0, inv=91000.0))
        await pd.tick(90000.0, BOOK)
        await pd.tick(90000.0, BOOK)
        assert pd.position and pd.position["side"] == "short"

        async def none_news():
            return ""

        async def none_verdict():
            return "вердикт"

        pd._gather_news = none_news
        pd._last_verdict = none_verdict
        answers = [{"choice": "ЖДЁМ", "why": "план жив"}]

        async def fake_ask(*a, **k):
            return answers[-1]

        pd._ai_ask_json = fake_ask
        await pd._review(90000.0)
        assert pd.position is not None
        fired3 = []

        async def cb3():
            fired3.append(1)

        pd.reanalyze_cb = cb3
        answers.append({"choice": "ЗАКРЫТЬ ВСЁ И ЖДАТЬ", "why": "слом"})
        await pd._review(90000.0)                 # нестрогая формулировка
        assert pd.position is None
        await asyncio.sleep(0)
        assert fired3
        pd._reanalyzing = False
        pd.state = "ЖДУ_ПЛАН"
        answers.append({"choice": "КУПИТЬ СЕЙЧАС!", "why": "разворот",
                        "invalidation": 95000.0})   # стоп ВЫШЕ цены — кривой
        await pd._review(90000.0)
        assert pd.plan and pd.plan["side"] == "long"
        assert abs(pd.plan["invalidation"] - 90000.0 * (1 - EMERGENCY_STOP_FRAC)) < 1e-3
        # дрейф: ИИ думал при 90000, цена уже 91000 (>1%) → вход отменён
        pd.plan = None
        pd._reanalyzing = False
        pd.prices.append(91000.0)
        fired3.clear()
        answers.append({"choice": "КУПИТЬ_СЕЙЧАС", "why": "поехали",
                        "invalidation": 89000.0})
        await pd._review(90000.0)
        assert pd.plan is None, "по протухшему решению не входим"
        await asyncio.sleep(0)
        #    ПЕЙСИНГ ДНЕВНОЙ СМЕНЫ: разбор только что был — второй подряд не
        #    жжём, просьба ОТКЛАДЫВАЕТСЯ (не теряется)
        assert not fired3 and pd._reanalyze_pending, \
            "второй разбор внутри окна пейсинга обязан быть отложен"
        #    окно открылось → пилот сам добирает отложенный разбор
        pd._last_reanalyze_ts -= (REANALYZE_GAP_SEC + 1)
        await pd.tick(91000.0, BOOK)
        await asyncio.sleep(0)
        assert fired3 and pd._reanalyze_pending is None, \
            "как только окно открылось — отложенный разбор обязан уйти"

        # 15) killswitch: закрыл, СТОП, приказы не принимаются; новый день —
        #     сброс и снова в строю
        pe = mk()
        pe.adopt_forecast(ex("BUY", inv=89000.0))
        await pe.tick(90000.0, BOOK)
        await pe.tick(90000.0, BOOK)
        assert pe.position
        pe.session_risk.locked = True
        pe.session_risk.reason = "тест-блок"
        await pe.tick(90000.0, BOOK)
        assert pe.position is None and pe.state == "СТОП"
        assert pe.adopt_forecast(ex("BUY", inv=89000.0)) is False, \
            "в killswitch свежий приказ не принимается"
        pe._sr_day -= 1                           # «наступил» новый день МСК
        await pe.tick(90000.0, BOOK)
        assert pe.state == "ЖДУ_ПЛАН" and not pe.session_risk.locked

        # 16) сверка: внешнее закрытие снимает стоп-сироту и пишет P/L
        pf_ = mk()
        pf_.adopt_forecast(ex("BUY", inv=89000.0))
        await pf_.tick(90000.0, BOOK)
        await pf_.tick(90000.0, BOOK)
        assert pf_.position and pf_.position.get("stop_id")
        pf_.broker.pf_positions = [{"figi": "FIGI-T", "qty": 0}]
        pf_.broker.pf_cash = 97000.0
        pf_._tick_n = RECONCILE_EVERY - 1
        await pf_.tick(90000.0, BOOK)             # сверка сработала
        assert pf_.position is None
        assert pf_.broker.stop_cancels, "стоп-сирота обязан быть снят"
        assert pf_._live_cash == 97000.0 and pf_.pnls

        # 17) обновление позиции свежим вердиктом той же стороны
        pg = mk()
        pg.adopt_forecast(ex("BUY", inv=89000.0, take=91000.0))
        await pg.tick(90000.0, BOOK)
        await pg.tick(90000.0, BOOK)
        assert pg.adopt_forecast(ex("BUY", inv=89500.0, take=92000.0))
        assert pg.position["invalidation"] == 89500.0 and pg.position["take"] == 92000.0
        await pg.tick(90000.0, BOOK)              # restop
        assert pg.broker.stops[-1]["stop"] == 89500.0

        # 18) снап цены к шагу: кривой уровень не уходит на биржу как есть
        ph = mk(tick=0.5)
        assert ph._snap(90000.37) in (90000.0, 90000.5)

        # 19) ДНЕВНАЯ СМЕНА: приказ протухает — по утренней засаде вечером
        #     не заходим, просим свежий разбор (пилот работает весь день)
        pi = mk()
        fired4 = []

        async def cb4():
            fired4.append(1)

        pi.reanalyze_cb = cb4
        pi.adopt_forecast(ex("BUY", entry=89500.0, take=91000.0, inv=89000.0))
        assert pi.state == "ЗАСАДА"
        pi.plan["ts"] -= (PLAN_TTL_SEC + 1)       # «прошло полдня»
        await pi.tick(89504.0, BOOK)              # цена у засады, но приказ стар
        assert pi.pending is None, "по протухшему приказу вход запрещён"
        assert pi.plan is None and pi.state in ("ЖДУ_ПЛАН", "ПЕРЕАНАЛИЗ")
        await asyncio.sleep(0)
        assert fired4, "протухший приказ → свежий разбор"
        assert pi.analyses == 1                   # счётчик смены живой

        # 20) рамка честности
        st = pg.status()
        assert "18+" in st["frame"] and st["pilot"] == "ИИ-ПИЛОТ"

        print("ai_pilot self-test OK (закалка веером): валидация приказа "
              "(стороны стоп/тейк), макс с плечом акций (dlong/dshort) и "
              "шорт-ГО, рыночный гейт, дозор ужимает (не убивает всё), "
              "двойное закрытие убито, отбитое закрытие добивается, паника "
              "забирает частичку, снимок уровней в заявке, мёртвая идея не "
              "покупается, REJECTED-бэкофф, эскалация без маркета, нестрогий "
              "разбор решений + дрейф, killswitch дневной, стоп-сирота "
              "снимается, свежий вердикт обновляет позицию")

    asyncio.run(main())
