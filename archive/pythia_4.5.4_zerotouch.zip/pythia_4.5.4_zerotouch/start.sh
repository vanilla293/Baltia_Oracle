#!/usr/bin/env bash
# ОРАКУЛ // ПИФИЯ — запуск (Linux/macOS)
set -e
cd "$(dirname "$0")"

PY=python3
command -v python3 >/dev/null 2>&1 || PY=python

if [ ! -x ".venv/bin/python" ]; then
  echo "[ПИФИЯ] создаю виртуальное окружение..."
  "$PY" -m venv .venv
fi

VPY=".venv/bin/python"
echo "[ПИФИЯ] ставлю зависимости..."
"$VPY" -m pip install -q --upgrade pip
"$VPY" -m pip install -q -r requirements.txt

echo "[ПИФИЯ] проверяю данные (эфемериды для астро/эфира)..."
"$VPY" -m backend.fetch_data || true

PORT="${PORT:-8799}"
echo "[ПИФИЯ] запуск на http://localhost:${PORT}"
exec "$VPY" -m uvicorn backend.server:app --host 0.0.0.0 --port "${PORT}"
