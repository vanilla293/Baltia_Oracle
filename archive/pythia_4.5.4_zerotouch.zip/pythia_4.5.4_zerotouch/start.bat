@echo off
REM ORACLE // PYTHIA - Windows launcher (ASCII only: Cyrillic + chcp inside
REM a .bat shifts cmd's read position and commands get cut mid-line)
setlocal
cd /d "%~dp0"

set "PY=python"
where python >nul 2>nul
if errorlevel 1 (
  where py >nul 2>nul
  if errorlevel 1 (
    echo [PYTHIA] Python not found in PATH. Install Python 3.10+ from python.org
    echo          and check "Add python.exe to PATH" during setup.
    pause
    exit /b 1
  )
  set "PY=py -3"
)

if not exist ".venv\Scripts\python.exe" (
  echo [PYTHIA] creating virtual environment...
  %PY% -m venv .venv
  if errorlevel 1 (
    echo [PYTHIA] venv creation FAILED - see error above.
    pause
    exit /b 1
  )
)

set "VPY=.venv\Scripts\python.exe"

echo [PYTHIA] installing dependencies...
"%VPY%" -m pip install -q --upgrade pip
"%VPY%" -m pip install -q -r requirements.txt
if errorlevel 1 (
  echo [PYTHIA] pip install FAILED - check internet / see error above.
  pause
  exit /b 1
)

echo [PYTHIA] checking data files (ephemeris for astro/ether)...
"%VPY%" -m backend.fetch_data

if "%PORT%"=="" set "PORT=8799"
echo [PYTHIA] starting at http://localhost:%PORT%
"%VPY%" -m uvicorn backend.server:app --host 0.0.0.0 --port %PORT%
pause
